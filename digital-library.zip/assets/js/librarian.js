// Librarian portal JavaScript functionality

document.addEventListener("DOMContentLoaded", () => {
  // Initialize librarian portal functionality
  initializeLibrarianPortal()
})

function initializeLibrarianPortal() {
  // Add active class to current page in navigation
  updateActiveNavigation()

  // Initialize filters functionality
  initializeFilters()

  // Initialize table actions
  initializeTableActions()
}

function updateActiveNavigation() {
  const currentPage = window.location.pathname.split("/").pop()
  const navLinks = document.querySelectorAll(".nav-menu a")

  navLinks.forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active")
    }
  })
}

function initializeFilters() {
  const filterForms = document.querySelectorAll(".filters-form")
  filterForms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      // Allow form submission
    })
  })
}

function initializeTableActions() {
  // Add event listeners for table action buttons
  document.addEventListener("click", (e) => {
    if (e.target.matches('[onclick*="deleteBook"]')) {
      e.preventDefault()
      const bookId = e.target.getAttribute("onclick").match(/\d+/)[0]
      deleteBook(bookId)
    }

    if (e.target.matches('[onclick*="returnBook"]')) {
      e.preventDefault()
      const borrowingId = e.target.getAttribute("onclick").match(/\d+/)[0]
      returnBook(borrowingId)
    }

    if (e.target.matches('[onclick*="renewBook"]')) {
      e.preventDefault()
      const borrowingId = e.target.getAttribute("onclick").match(/\d+/)[0]
      renewBook(borrowingId)
    }

    if (e.target.matches('[onclick*="viewDetails"]')) {
      e.preventDefault()
      const borrowingId = e.target.getAttribute("onclick").match(/\d+/)[0]
      viewDetails(borrowingId)
    }
  })
}

function deleteBook(bookId) {
  if (!confirm("Are you sure you want to delete this book? This action cannot be undone.")) {
    return
  }

  const button = event.target
  const originalText = button.textContent
  button.textContent = "Deleting..."
  button.disabled = true

  fetch("../api/delete-book.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      book_id: bookId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showMessage("Book deleted successfully!", "success")
        // Remove the row from table
        const row = button.closest("tr")
        if (row) {
          row.style.animation = "fadeOut 0.3s ease"
          setTimeout(() => {
            row.remove()
          }, 300)
        }
      } else {
        showMessage(data.message || "Failed to delete book", "error")
        button.textContent = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showMessage("An error occurred while deleting the book", "error")
      button.textContent = originalText
      button.disabled = false
    })
}

function returnBook(borrowingId) {
  if (!confirm("Mark this book as returned?")) {
    return
  }

  const button = event.target
  const originalText = button.textContent
  button.textContent = "Processing..."
  button.disabled = true

  fetch("../api/return-book.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      borrowing_id: borrowingId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showMessage("Book returned successfully!", "success")
        // Refresh the page to update the table
        setTimeout(() => {
          window.location.reload()
        }, 1500)
      } else {
        showMessage(data.message || "Failed to return book", "error")
        button.textContent = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showMessage("An error occurred while returning the book", "error")
      button.textContent = originalText
      button.disabled = false
    })
}

function renewBook(borrowingId) {
  if (!confirm("Renew this book for another loan period?")) {
    return
  }

  const button = event.target
  const originalText = button.textContent
  button.textContent = "Renewing..."
  button.disabled = true

  fetch("../api/renew-book.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      borrowing_id: borrowingId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showMessage("Book renewed successfully!", "success")
        // Refresh the page to show updated due date
        setTimeout(() => {
          window.location.reload()
        }, 1500)
      } else {
        showMessage(data.message || "Failed to renew book", "error")
        button.textContent = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showMessage("An error occurred while renewing the book", "error")
      button.textContent = originalText
      button.disabled = false
    })
}

function viewDetails(borrowingId) {
  // Open a modal or navigate to details page
  window.open(`borrowing-details.php?id=${borrowingId}`, "_blank", "width=800,height=600")
}

function showMessage(message, type = "info") {
  // Remove existing messages
  const existingMessages = document.querySelectorAll(".message-toast")
  existingMessages.forEach((msg) => msg.remove())

  // Create message element
  const messageDiv = document.createElement("div")
  messageDiv.className = `message-toast message-${type}`
  messageDiv.textContent = message

  // Style the message
  messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 6px;
        color: white;
        font-weight: 500;
        z-index: 1000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideIn 0.3s ease;
    `

  // Set background color based on type
  switch (type) {
    case "success":
      messageDiv.style.backgroundColor = "#48bb78"
      break
    case "error":
      messageDiv.style.backgroundColor = "#f56565"
      break
    case "warning":
      messageDiv.style.backgroundColor = "#ed8936"
      break
    default:
      messageDiv.style.backgroundColor = "#4299e1"
  }

  // Add to page
  document.body.appendChild(messageDiv)

  // Remove after 4 seconds
  setTimeout(() => {
    messageDiv.style.animation = "slideOut 0.3s ease"
    setTimeout(() => {
      if (messageDiv.parentNode) {
        messageDiv.parentNode.removeChild(messageDiv)
      }
    }, 300)
  }, 4000)
}

// Add CSS animations for messages and table rows
const style = document.createElement("style")
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    @keyframes fadeOut {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }
`
document.head.appendChild(style)
