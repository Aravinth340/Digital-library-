// Student portal JavaScript functionality

document.addEventListener("DOMContentLoaded", () => {
  // Initialize page functionality
  initializeStudentPortal()
})

function initializeStudentPortal() {
  // Add active class to current page in navigation
  updateActiveNavigation()

  // Initialize search functionality
  initializeSearch()

  // Initialize book actions
  initializeBookActions()
}

function updateActiveNavigation() {
  const currentPage = window.location.pathname.split("/").pop()
  const navLinks = document.querySelectorAll(".nav-menu a")

  navLinks.forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active")
    }
  })
}

function initializeSearch() {
  const searchForm = document.querySelector(".search-form")
  if (searchForm) {
    searchForm.addEventListener("submit", function (e) {
      const searchInput = this.querySelector('input[name="search"]')
      if (searchInput && searchInput.value.trim() === "") {
        // Allow empty search to show all books
      }
    })
  }
}

function initializeBookActions() {
  // Add event listeners for book action buttons
  document.addEventListener("click", (e) => {
    if (e.target.matches('[onclick*="reserveBook"]')) {
      e.preventDefault()
      const bookId = e.target.getAttribute("onclick").match(/\d+/)[0]
      reserveBook(bookId)
    }

    if (e.target.matches('[onclick*="renewBook"]')) {
      e.preventDefault()
      const borrowingId = e.target.getAttribute("onclick").match(/\d+/)[0]
      renewBook(borrowingId)
    }
  })
}

function reserveBook(bookId) {
  if (!confirm("Are you sure you want to reserve this book?")) {
    return
  }

  const button = event.target
  const originalText = button.textContent
  button.textContent = "Reserving..."
  button.disabled = true

  fetch("../api/reserve-book.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      book_id: bookId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showMessage("Book reserved successfully!", "success")
        button.textContent = "Reserved"
        button.classList.remove("btn-primary")
        button.classList.add("btn-disabled")
      } else {
        showMessage(data.message || "Failed to reserve book", "error")
        button.textContent = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showMessage("An error occurred while reserving the book", "error")
      button.textContent = originalText
      button.disabled = false
    })
}

function renewBook(borrowingId) {
  if (!confirm("Are you sure you want to renew this book?")) {
    return
  }

  const button = event.target
  const originalText = button.textContent
  button.textContent = "Renewing..."
  button.disabled = true

  fetch("../api/renew-book.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      borrowing_id: borrowingId,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        showMessage("Book renewed successfully!", "success")
        // Refresh the page to show updated due date
        setTimeout(() => {
          window.location.reload()
        }, 1500)
      } else {
        showMessage(data.message || "Failed to renew book", "error")
        button.textContent = originalText
        button.disabled = false
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showMessage("An error occurred while renewing the book", "error")
      button.textContent = originalText
      button.disabled = false
    })
}

function showMessage(message, type = "info") {
  // Remove existing messages
  const existingMessages = document.querySelectorAll(".message-toast")
  existingMessages.forEach((msg) => msg.remove())

  // Create message element
  const messageDiv = document.createElement("div")
  messageDiv.className = `message-toast message-${type}`
  messageDiv.textContent = message

  // Style the message
  messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 6px;
        color: white;
        font-weight: 500;
        z-index: 1000;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        animation: slideIn 0.3s ease;
    `

  // Set background color based on type
  switch (type) {
    case "success":
      messageDiv.style.backgroundColor = "#48bb78"
      break
    case "error":
      messageDiv.style.backgroundColor = "#f56565"
      break
    case "warning":
      messageDiv.style.backgroundColor = "#ed8936"
      break
    default:
      messageDiv.style.backgroundColor = "#4299e1"
  }

  // Add to page
  document.body.appendChild(messageDiv)

  // Remove after 4 seconds
  setTimeout(() => {
    messageDiv.style.animation = "slideOut 0.3s ease"
    setTimeout(() => {
      if (messageDiv.parentNode) {
        messageDiv.parentNode.removeChild(messageDiv)
      }
    }, 300)
  }, 4000)
}

// Add CSS animations
const style = document.createElement("style")
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`
document.head.appendChild(style)
