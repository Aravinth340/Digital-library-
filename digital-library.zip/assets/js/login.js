// Login form handling
document.addEventListener("DOMContentLoaded", () => {
  // Get error message from URL parameters
  const urlParams = new URLSearchParams(window.location.search)
  const error = urlParams.get("error")

  if (error) {
    showErrorMessage(getErrorMessage(error))
  }

  // Handle form submissions
  const loginForms = document.querySelectorAll(".login-form")
  loginForms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      const username = form.querySelector('input[name="username"]').value.trim()
      const password = form.querySelector('input[name="password"]').value.trim()

      if (!username || !password) {
        e.preventDefault()
        showErrorMessage("Please fill in all fields.")
        return false
      }

      // Show loading state
      const submitBtn = form.querySelector('button[type="submit"]')
      const originalText = submitBtn.textContent
      submitBtn.textContent = "Logging in..."
      submitBtn.disabled = true

      // Re-enable button after a delay in case of server error
      setTimeout(() => {
        submitBtn.textContent = originalText
        submitBtn.disabled = false
      }, 5000)
    })
  })
})

function getErrorMessage(error) {
  const errorMessages = {
    empty_fields: "Please fill in all fields.",
    invalid_credentials: "Invalid username or password.",
    user_not_found: "User not found or account is inactive.",
    invalid_password: "Invalid password.",
    account_inactive: "Your account is inactive. Please contact the administrator.",
    login_failed: "Login failed. Please try again.",
  }

  return errorMessages[error] || "An error occurred. Please try again."
}

function showErrorMessage(message) {
  // Remove existing error messages
  const existingErrors = document.querySelectorAll(".error-message")
  existingErrors.forEach((error) => error.remove())

  // Create and show new error message
  const errorDiv = document.createElement("div")
  errorDiv.className = "error-message"
  errorDiv.textContent = message

  const form = document.querySelector(".login-form")
  if (form) {
    form.insertBefore(errorDiv, form.firstChild)
  }
}

function showSuccessMessage(message) {
  // Remove existing messages
  const existingMessages = document.querySelectorAll(".error-message, .success-message")
  existingMessages.forEach((msg) => msg.remove())

  // Create and show success message
  const successDiv = document.createElement("div")
  successDiv.className = "success-message"
  successDiv.textContent = message

  const form = document.querySelector(".login-form")
  if (form) {
    form.insertBefore(successDiv, form.firstChild)
  }
}

// Password visibility toggle (optional enhancement)
function togglePasswordVisibility(inputId) {
  const input = document.getElementById(inputId)
  const type = input.getAttribute("type") === "password" ? "text" : "password"
  input.setAttribute("type", type)
}
