<?php
require_once 'config.php';

class Logger {
    private static $instance = null;
    private $log_file;
    
    private function __construct() {
        $this->log_file = LOG_PATH . 'app_' . date('Y-m-d') . '.log';
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Logger();
        }
        return self::$instance;
    }
    
    public function log($level, $message, $context = []) {
        $timestamp = date('Y-m-d H:i:s');
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'anonymous';
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        $log_entry = [
            'timestamp' => $timestamp,
            'level' => strtoupper($level),
            'user_id' => $user_id,
            'ip' => $ip,
            'message' => $message,
            'context' => $context
        ];
        
        $log_line = json_encode($log_entry) . PHP_EOL;
        file_put_contents($this->log_file, $log_line, FILE_APPEND | LOCK_EX);
    }
    
    public function debug($message, $context = []) {
        $this->log('DEBUG', $message, $context);
    }
    
    public function info($message, $context = []) {
        $this->log('INFO', $message, $context);
    }
    
    public function warning($message, $context = []) {
        $this->log('WARNING', $message, $context);
    }
    
    public function error($message, $context = []) {
        $this->log('ERROR', $message, $context);
    }
}
?>
