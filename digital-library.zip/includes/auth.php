<?php
session_start();
require_once '../config/database.php';

class Auth {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function login($username, $password, $user_type) {
        try {
            $query = "SELECT id, username, email, full_name, user_type, student_id, status 
                     FROM users 
                     WHERE username = :username AND user_type = :user_type AND status = 'active'";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':user_type', $user_type);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verify password (assuming passwords are hashed)
                $password_query = "SELECT password FROM users WHERE id = :id";
                $password_stmt = $this->conn->prepare($password_query);
                $password_stmt->bindParam(':id', $user['id']);
                $password_stmt->execute();
                $password_row = $password_stmt->fetch(PDO::FETCH_ASSOC);
                
                if (password_verify($password, $password_row['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $_SESSION['student_id'] = $user['student_id'];
                    $_SESSION['logged_in'] = true;
                    
                    return array('success' => true, 'user' => $user);
                } else {
                    return array('success' => false, 'message' => 'Invalid password');
                }
            } else {
                return array('success' => false, 'message' => 'User not found or inactive');
            }
        } catch (Exception $e) {
            return array('success' => false, 'message' => 'Login failed: ' . $e->getMessage());
        }
    }
    
    public function logout() {
        session_destroy();
        return true;
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    
    public function getUserType() {
        return isset($_SESSION['user_type']) ? $_SESSION['user_type'] : null;
    }
    
    public function requireLogin($required_type = null) {
        if (!$this->isLoggedIn()) {
            header('Location: /login.php');
            exit();
        }
        
        if ($required_type && $this->getUserType() !== $required_type) {
            header('Location: /unauthorized.php');
            exit();
        }
    }
}
?>
