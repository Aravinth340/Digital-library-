# Digital Library Management System

A comprehensive web-based library management system built with PHP, MySQL, HTML, CSS, and JavaScript. Designed for college/university libraries with separate interfaces for students and librarians.

## Features

### Student Features
- **Browse Books**: Search and filter library collection by title, author, ISBN, or category
- **Account Management**: View borrowed books, due dates, and borrowing history
- **Book Reservations**: Reserve books that are currently unavailable
- **Renewals**: Renew borrowed books (if not overdue)
- **Fine Tracking**: View pending fines and payment status

### Librarian Features
- **Dashboard**: System overview with statistics and alerts
- **Book Management**: Add, edit, delete, and manage book inventory
- **User Management**: Manage student accounts and permissions
- **Borrowing System**: Issue books, process returns, calculate fines
- **Reservations**: Manage and fulfill book reservations
- **Reports**: Generate system reports and export data
- **System Health**: Monitor system performance and alerts

### System Features
- **Role-based Authentication**: Separate login portals for students and librarians
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Real-time Inventory**: Automatic tracking of book availability
- **Fine Calculation**: Automatic calculation of overdue fines
- **Audit Trail**: Complete logging of all system activities
- **Data Export**: Export books, users, and borrowing data

## Installation

### Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- Modern web browser

### Setup Instructions

1. **Clone/Download** the project files to your web server directory

2. **Database Setup**:
   - Create a MySQL database named `digital_library`
   - Import the SQL files in order:
     - `scripts/01_create_database.sql`
     - `scripts/02_insert_sample_data.sql`
     - `scripts/03_create_indexes.sql`

3. **Configuration**:
   - Update database credentials in `config/database.php`
   - Modify settings in `config/config.php` as needed
   - Ensure `uploads/` and `logs/` directories are writable

4. **Web Server Setup**:
   - Point your web server document root to the project directory
   - Ensure PHP has necessary permissions for file operations
   - Enable PHP extensions: PDO, PDO_MySQL, JSON

5. **Access the System**:
   - Navigate to your domain/IP address
   - Use the setup wizard at `/install/setup.php` for guided installation
   - Default admin credentials: `admin` / `password` (change immediately)

## Default Accounts

### Librarian
- **Username**: admin
- **Password**: password
- **Email**: librarian@college.edu

### Sample Students
- **Username**: john_doe / **Password**: password
- **Username**: jane_smith / **Password**: password

## File Structure

\`\`\`
digital-library/
├── api/                    # REST API endpoints
├── assets/                 # CSS, JS, and static files
├── auth/                   # Authentication handlers
├── config/                 # Configuration files
├── includes/               # Shared PHP classes and functions
├── install/                # Installation wizard
├── librarian/              # Librarian interface pages
├── logs/                   # System logs (auto-created)
├── scripts/                # Database setup scripts
├── student/                # Student interface pages
├── uploads/                # File uploads (auto-created)
└── index.html             # Main landing page
\`\`\`

## Configuration

### Database Settings
Edit `config/database.php`:
\`\`\`php
private $host = 'localhost';
private $db_name = 'digital_library';
private $username = 'your_db_user';
private $password = 'your_db_password';
\`\`\`

### System Settings
Modify `config/config.php` for:
- Application URL and timezone
- Session configuration
- File upload limits
- Email settings
- Security parameters

### Library Policies
Update system settings through the librarian interface:
- Maximum books per student
- Loan period duration
- Fine amount per day
- Reservation hold period

## Security Features

- **Password Hashing**: Bcrypt with configurable cost
- **Session Management**: Secure session handling with timeout
- **SQL Injection Protection**: Prepared statements throughout
- **XSS Prevention**: Input sanitization and output escaping
- **CSRF Protection**: Form token validation
- **Access Control**: Role-based permissions
- **Audit Logging**: Complete activity tracking

## API Endpoints

### Authentication
- `POST /auth/student-login.php` - Student login
- `POST /auth/librarian-login.php` - Librarian login
- `GET /auth/logout.php` - Logout

### Books
- `GET /api/search-books.php` - Search books
- `POST /api/reserve-book.php` - Reserve a book
- `POST /api/renew-book.php` - Renew borrowed book

### System
- `GET /api/user-stats.php` - User statistics
- `GET /api/system-health.php` - System health check
- `GET /api/export-data.php` - Export data

## Customization

### Styling
- Main styles: `assets/css/style.css`
- Dashboard: `assets/css/dashboard.css`
- Forms: `assets/css/forms.css`
- Librarian: `assets/css/librarian.css`

### Functionality
- Authentication: `includes/auth.php`
- Database: `config/database.php`
- Logging: `includes/logger.php`

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Verify database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Check database exists and user has permissions

2. **Permission Denied Errors**
   - Ensure web server has write permissions to `uploads/` and `logs/`
   - Check PHP file permissions

3. **Session Issues**
   - Verify session configuration in `config/config.php`
   - Check server session storage permissions

4. **Login Problems**
   - Verify user accounts exist in database
   - Check password hashing compatibility
   - Review authentication logs

### Logs
- Application logs: `logs/app_YYYY-MM-DD.log`
- Error logs: Check web server error logs
- Database logs: Check MySQL error logs

## Support

For technical support or questions:
- Check the troubleshooting section
- Review system logs for error details
- Verify configuration settings
- Ensure all requirements are met

## License

This project is open source and available under the MIT License.
