<?php
require_once '../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    if (empty($username) || empty($password)) {
        header('Location: ../librarian-login.html?error=empty_fields');
        exit();
    }
    
    $auth = new Auth();
    $result = $auth->login($username, $password, 'librarian');
    
    if ($result['success']) {
        header('Location: ../librarian/dashboard.php');
        exit();
    } else {
        header('Location: ../librarian-login.html?error=' . urlencode($result['message']));
        exit();
    }
} else {
    header('Location: ../librarian-login.html');
    exit();
}
?>
