-- Insert default categories
INSERT INTO categories (name, description) VALUES
('Fiction', 'Novels, short stories, and other fictional works'),
('Non-Fiction', 'Biographies, history, science, and factual books'),
('Science & Technology', 'Computer science, engineering, mathematics, physics'),
('Literature', 'Classic literature, poetry, and literary criticism'),
('Reference', 'Dictionaries, encyclopedias, and reference materials'),
('Academic', 'Textbooks and academic publications'),
('Magazines', 'Periodicals and magazines'),
('Research Papers', 'Academic research and thesis papers');

-- Insert default librarian account
INSERT INTO users (username, email, password, full_name, user_type, phone, address) VALUES
('admin', 'librarian@college.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Head Librarian', 'librarian', '123-456-7890', 'Library Office, Main Building');

-- Insert sample student accounts
INSERT INTO users (username, email, password, full_name, user_type, student_id, phone) VALUES
('john_doe', 'john.doe@student.college.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', 'student', 'STU001', '987-654-3210'),
('jane_smith', 'jane.smith@student.college.edu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Smith', 'student', 'STU002', '987-654-3211');

-- Insert sample books
INSERT INTO books (isbn, title, author, publisher, publication_year, category_id, total_copies, available_copies, description, shelf_location) VALUES
('978-0-13-110362-7', 'The C Programming Language', 'Brian Kernighan, Dennis Ritchie', 'Prentice Hall', 1988, 3, 5, 5, 'Classic programming book for C language', 'A1-001'),
('978-0-321-35668-0', 'Effective Java', 'Joshua Bloch', 'Addison-Wesley', 2008, 3, 3, 3, 'Best practices for Java programming', 'A1-015'),
('978-0-7432-7356-5', 'To Kill a Mockingbird', 'Harper Lee', 'J.B. Lippincott & Co.', 1960, 1, 4, 4, 'Classic American literature', 'B2-045'),
('978-0-14-028329-7', '1984', 'George Orwell', 'Penguin Books', 1949, 1, 6, 6, 'Dystopian social science fiction novel', 'B2-067'),
('978-0-13-235088-4', 'Database System Concepts', 'Abraham Silberschatz', 'McGraw-Hill', 2019, 6, 8, 8, 'Comprehensive database systems textbook', 'C3-012');

-- Insert system settings
INSERT INTO settings (setting_key, setting_value, description) VALUES
('max_books_per_student', '3', 'Maximum number of books a student can borrow at once'),
('loan_period_days', '14', 'Default loan period in days'),
('fine_per_day', '1.00', 'Fine amount per day for overdue books'),
('max_reservation_days', '7', 'Maximum days a reservation is held'),
('library_name', 'College Digital Library', 'Name of the library system'),
('library_email', 'library@college.edu', 'Library contact email'),
('library_phone', '555-0123', 'Library contact phone number');
