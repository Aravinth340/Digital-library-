<?php
require_once '../includes/auth.php';
require_once '../config/database.php';
require_once '../includes/logger.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn() || $auth->getUserType() !== 'librarian') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();
$logger = Logger::getInstance();

try {
    $health_data = [];
    
    // Database connectivity
    $health_data['database'] = [
        'status' => 'connected',
        'version' => $conn->getAttribute(PDO::ATTR_SERVER_VERSION)
    ];
    
    // System statistics
    $stats_queries = [
        'total_books' => "SELECT COUNT(*) as count FROM books",
        'available_books' => "SELECT COUNT(*) as count FROM books WHERE available_copies > 0",
        'total_users' => "SELECT COUNT(*) as count FROM users WHERE user_type = 'student'",
        'active_borrowings' => "SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed'",
        'overdue_books' => "SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed' AND due_date < CURDATE()",
        'pending_reservations' => "SELECT COUNT(*) as count FROM reservations WHERE status = 'active'",
        'pending_fines' => "SELECT COALESCE(SUM(amount), 0) as total FROM fines WHERE status = 'pending'"
    ];
    
    $health_data['statistics'] = [];
    foreach ($stats_queries as $key => $query) {
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $health_data['statistics'][$key] = $key === 'pending_fines' ? (float)$result['total'] : (int)$result['count'];
    }
    
    // Recent activity
    $recent_activity_query = "SELECT 'borrowing' as type, borrowed_date as date, COUNT(*) as count 
                             FROM borrowings 
                             WHERE borrowed_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                             GROUP BY borrowed_date 
                             ORDER BY borrowed_date DESC 
                             LIMIT 7";
    $activity_stmt = $conn->prepare($recent_activity_query);
    $activity_stmt->execute();
    $health_data['recent_activity'] = $activity_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // System alerts
    $alerts = [];
    
    // Check for overdue books
    if ($health_data['statistics']['overdue_books'] > 0) {
        $alerts[] = [
            'type' => 'warning',
            'message' => $health_data['statistics']['overdue_books'] . ' books are overdue'
        ];
    }
    
    // Check for low stock books
    $low_stock_query = "SELECT COUNT(*) as count FROM books WHERE available_copies <= 1 AND total_copies > 1";
    $low_stock_stmt = $conn->prepare($low_stock_query);
    $low_stock_stmt->execute();
    $low_stock_count = $low_stock_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($low_stock_count > 0) {
        $alerts[] = [
            'type' => 'info',
            'message' => $low_stock_count . ' books are running low on stock'
        ];
    }
    
    // Check for expired reservations
    $expired_reservations_query = "SELECT COUNT(*) as count FROM reservations WHERE status = 'active' AND expiry_date < CURDATE()";
    $expired_stmt = $conn->prepare($expired_reservations_query);
    $expired_stmt->execute();
    $expired_count = $expired_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($expired_count > 0) {
        $alerts[] = [
            'type' => 'warning',
            'message' => $expired_count . ' reservations have expired'
        ];
    }
    
    $health_data['alerts'] = $alerts;
    $health_data['system_info'] = [
        'php_version' => PHP_VERSION,
        'server_time' => date('Y-m-d H:i:s'),
        'uptime' => sys_getloadavg()[0] ?? 'N/A'
    ];
    
    $logger->info('System health check performed', ['user_id' => $_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'health' => $health_data,
        'timestamp' => date('c')
    ]);
    
} catch (Exception $e) {
    $logger->error('System health check failed', ['error' => $e->getMessage()]);
    echo json_encode(['success' => false, 'message' => 'Health check failed: ' . $e->getMessage()]);
}
?>
