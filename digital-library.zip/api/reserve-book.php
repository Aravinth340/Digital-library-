<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn() || $auth->getUserType() !== 'student') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$book_id = isset($input['book_id']) ? (int)$input['book_id'] : 0;

if (!$book_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    // Check if book exists and is available for reservation
    $book_query = "SELECT * FROM books WHERE id = :id AND status = 'available'";
    $book_stmt = $conn->prepare($book_query);
    $book_stmt->bindParam(':id', $book_id);
    $book_stmt->execute();
    $book = $book_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        echo json_encode(['success' => false, 'message' => 'Book not found or not available']);
        exit();
    }
    
    // Check if student already has this book borrowed
    $borrowed_check = "SELECT id FROM borrowings WHERE user_id = :user_id AND book_id = :book_id AND status = 'borrowed'";
    $borrowed_stmt = $conn->prepare($borrowed_check);
    $borrowed_stmt->bindParam(':user_id', $_SESSION['user_id']);
    $borrowed_stmt->bindParam(':book_id', $book_id);
    $borrowed_stmt->execute();
    
    if ($borrowed_stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'You already have this book borrowed']);
        exit();
    }
    
    // Check if student already has this book reserved
    $reservation_check = "SELECT id FROM reservations WHERE user_id = :user_id AND book_id = :book_id AND status = 'active'";
    $reservation_stmt = $conn->prepare($reservation_check);
    $reservation_stmt->bindParam(':user_id', $_SESSION['user_id']);
    $reservation_stmt->bindParam(':book_id', $book_id);
    $reservation_stmt->execute();
    
    if ($reservation_stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'You already have this book reserved']);
        exit();
    }
    
    // Get reservation period setting
    $settings_query = "SELECT setting_value FROM settings WHERE setting_key = 'max_reservation_days'";
    $settings_stmt = $conn->prepare($settings_query);
    $settings_stmt->execute();
    $reservation_days = (int)$settings_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
    
    // Create reservation
    $reservation_date = date('Y-m-d');
    $expiry_date = date('Y-m-d', strtotime("+$reservation_days days"));
    
    $insert_query = "INSERT INTO reservations (user_id, book_id, reservation_date, expiry_date, status) 
                    VALUES (:user_id, :book_id, :reservation_date, :expiry_date, 'active')";
    $insert_stmt = $conn->prepare($insert_query);
    $insert_stmt->bindParam(':user_id', $_SESSION['user_id']);
    $insert_stmt->bindParam(':book_id', $book_id);
    $insert_stmt->bindParam(':reservation_date', $reservation_date);
    $insert_stmt->bindParam(':expiry_date', $expiry_date);
    
    if ($insert_stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Book reserved successfully',
            'expiry_date' => date('M j, Y', strtotime($expiry_date))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to create reservation']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
