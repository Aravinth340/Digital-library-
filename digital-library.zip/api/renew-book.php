<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$borrowing_id = isset($input['borrowing_id']) ? (int)$input['borrowing_id'] : 0;

if (!$borrowing_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid borrowing ID']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    // Get borrowing details
    $borrowing_query = "SELECT b.*, bk.title 
                       FROM borrowings b 
                       JOIN books bk ON b.book_id = bk.id 
                       WHERE b.id = :id AND b.status = 'borrowed'";
    $borrowing_stmt = $conn->prepare($borrowing_query);
    $borrowing_stmt->bindParam(':id', $borrowing_id);
    $borrowing_stmt->execute();
    $borrowing = $borrowing_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$borrowing) {
        echo json_encode(['success' => false, 'message' => 'Borrowing record not found']);
        exit();
    }
    
    // Check if user owns this borrowing (students can only renew their own books)
    if ($auth->getUserType() === 'student' && $borrowing['user_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'You can only renew your own books']);
        exit();
    }
    
    // Check if book is overdue (some libraries don't allow renewal of overdue books)
    if (strtotime($borrowing['due_date']) < time()) {
        echo json_encode(['success' => false, 'message' => 'Cannot renew overdue books. Please return the book first.']);
        exit();
    }
    
    // Get loan period setting
    $settings_query = "SELECT setting_value FROM settings WHERE setting_key = 'loan_period_days'";
    $settings_stmt = $conn->prepare($settings_query);
    $settings_stmt->execute();
    $loan_days = (int)$settings_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
    
    // Calculate new due date
    $new_due_date = date('Y-m-d', strtotime($borrowing['due_date'] . " +$loan_days days"));
    
    // Update borrowing record
    $update_query = "UPDATE borrowings SET due_date = :new_due_date WHERE id = :id";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bindParam(':new_due_date', $new_due_date);
    $update_stmt->bindParam(':id', $borrowing_id);
    
    if ($update_stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Book renewed successfully',
            'new_due_date' => date('M j, Y', strtotime($new_due_date))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to renew book']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
