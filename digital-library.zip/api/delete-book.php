<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn() || $auth->getUserType() !== 'librarian') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$book_id = isset($input['book_id']) ? (int)$input['book_id'] : 0;

if (!$book_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid book ID']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    // Check if book has active borrowings
    $borrowings_check = "SELECT COUNT(*) as active_borrowings FROM borrowings WHERE book_id = :book_id AND status = 'borrowed'";
    $borrowings_stmt = $conn->prepare($borrowings_check);
    $borrowings_stmt->bindParam(':book_id', $book_id);
    $borrowings_stmt->execute();
    $active_borrowings = $borrowings_stmt->fetch(PDO::FETCH_ASSOC)['active_borrowings'];
    
    if ($active_borrowings > 0) {
        echo json_encode(['success' => false, 'message' => 'Cannot delete book with active borrowings']);
        exit();
    }
    
    // Delete the book
    $delete_query = "DELETE FROM books WHERE id = :id";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bindParam(':id', $book_id);
    
    if ($delete_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Book deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete book']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
