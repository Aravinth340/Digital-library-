<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn() || $auth->getUserType() !== 'librarian') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$borrowing_id = isset($input['borrowing_id']) ? (int)$input['borrowing_id'] : 0;

if (!$borrowing_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid borrowing ID']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    $conn->beginTransaction();
    
    // Get borrowing details
    $borrowing_query = "SELECT * FROM borrowings WHERE id = :id AND status = 'borrowed'";
    $borrowing_stmt = $conn->prepare($borrowing_query);
    $borrowing_stmt->bindParam(':id', $borrowing_id);
    $borrowing_stmt->execute();
    $borrowing = $borrowing_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$borrowing) {
        echo json_encode(['success' => false, 'message' => 'Borrowing record not found or already returned']);
        exit();
    }
    
    // Update borrowing record
    $return_date = date('Y-m-d');
    $update_borrowing = "UPDATE borrowings SET 
                        return_date = :return_date, 
                        status = 'returned', 
                        returned_to = :returned_to 
                        WHERE id = :id";
    $update_stmt = $conn->prepare($update_borrowing);
    $update_stmt->bindParam(':return_date', $return_date);
    $update_stmt->bindParam(':returned_to', $_SESSION['user_id']);
    $update_stmt->bindParam(':id', $borrowing_id);
    $update_stmt->execute();
    
    // Update book availability
    $update_book = "UPDATE books SET available_copies = available_copies + 1 WHERE id = :book_id";
    $update_book_stmt = $conn->prepare($update_book);
    $update_book_stmt->bindParam(':book_id', $borrowing['book_id']);
    $update_book_stmt->execute();
    
    $conn->commit();
    
    echo json_encode(['success' => true, 'message' => 'Book returned successfully']);
    
} catch (Exception $e) {
    $conn->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
