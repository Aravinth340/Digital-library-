<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
if (!$auth->isLoggedIn() || $auth->getUserType() !== 'librarian') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$export_type = isset($_GET['type']) ? $_GET['type'] : 'books';
$format = isset($_GET['format']) ? $_GET['format'] : 'csv';

$database = new Database();
$conn = $database->getConnection();

try {
    $data = [];
    $filename = '';
    
    switch ($export_type) {
        case 'books':
            $query = "SELECT b.*, c.name as category_name 
                     FROM books b 
                     LEFT JOIN categories c ON b.category_id = c.id 
                     ORDER BY b.title";
            $filename = 'books_export_' . date('Y-m-d');
            break;
            
        case 'borrowings':
            $query = "SELECT b.*, bk.title, bk.author, u.full_name, u.student_id 
                     FROM borrowings b 
                     JOIN books bk ON b.book_id = bk.id 
                     JOIN users u ON b.user_id = u.id 
                     ORDER BY b.borrowed_date DESC";
            $filename = 'borrowings_export_' . date('Y-m-d');
            break;
            
        case 'users':
            $query = "SELECT id, username, email, full_name, user_type, student_id, status, created_at 
                     FROM users 
                     WHERE user_type = 'student' 
                     ORDER BY full_name";
            $filename = 'users_export_' . date('Y-m-d');
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid export type']);
            exit();
    }
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        
        $output = fopen('php://output', 'w');
        
        if (!empty($data)) {
            // Write headers
            fputcsv($output, array_keys($data[0]));
            
            // Write data
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        
    } elseif ($format === 'json') {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '.json"');
        
        echo json_encode([
            'export_type' => $export_type,
            'export_date' => date('Y-m-d H:i:s'),
            'total_records' => count($data),
            'data' => $data
        ], JSON_PRETTY_PRINT);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Export failed: ' . $e->getMessage()]);
}
?>
