<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    $user_id = $_SESSION['user_id'];
    $stats = [];
    
    if ($auth->getUserType() === 'student') {
        // Student statistics
        $borrowed_query = "SELECT COUNT(*) as count FROM borrowings WHERE user_id = :user_id AND status = 'borrowed'";
        $borrowed_stmt = $conn->prepare($borrowed_query);
        $borrowed_stmt->bindParam(':user_id', $user_id);
        $borrowed_stmt->execute();
        $stats['borrowed_books'] = $borrowed_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $overdue_query = "SELECT COUNT(*) as count FROM borrowings WHERE user_id = :user_id AND status = 'borrowed' AND due_date < CURDATE()";
        $overdue_stmt = $conn->prepare($overdue_query);
        $overdue_stmt->bindParam(':user_id', $user_id);
        $overdue_stmt->execute();
        $stats['overdue_books'] = $overdue_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $reservations_query = "SELECT COUNT(*) as count FROM reservations WHERE user_id = :user_id AND status = 'active'";
        $reservations_stmt = $conn->prepare($reservations_query);
        $reservations_stmt->bindParam(':user_id', $user_id);
        $reservations_stmt->execute();
        $stats['active_reservations'] = $reservations_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $fines_query = "SELECT COALESCE(SUM(amount), 0) as total FROM fines WHERE user_id = :user_id AND status = 'pending'";
        $fines_stmt = $conn->prepare($fines_query);
        $fines_stmt->bindParam(':user_id', $user_id);
        $fines_stmt->execute();
        $stats['pending_fines'] = (float)$fines_stmt->fetch(PDO::FETCH_ASSOC)['total'];
        
    } elseif ($auth->getUserType() === 'librarian') {
        // Librarian statistics
        $books_query = "SELECT COUNT(*) as count FROM books";
        $books_stmt = $conn->prepare($books_query);
        $books_stmt->execute();
        $stats['total_books'] = $books_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $students_query = "SELECT COUNT(*) as count FROM users WHERE user_type = 'student'";
        $students_stmt = $conn->prepare($students_query);
        $students_stmt->execute();
        $stats['total_students'] = $students_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $active_borrowings_query = "SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed'";
        $active_borrowings_stmt = $conn->prepare($active_borrowings_query);
        $active_borrowings_stmt->execute();
        $stats['active_borrowings'] = $active_borrowings_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $overdue_system_query = "SELECT COUNT(*) as count FROM borrowings WHERE status = 'borrowed' AND due_date < CURDATE()";
        $overdue_system_stmt = $conn->prepare($overdue_system_query);
        $overdue_system_stmt->execute();
        $stats['overdue_books'] = $overdue_system_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    }
    
    echo json_encode([
        'success' => true,
        'stats' => $stats
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error fetching stats: ' . $e->getMessage()]);
}
?>
