<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$limit = isset($_GET['limit']) ? min((int)$_GET['limit'], 50) : 10;

if (empty($query) && !$category) {
    echo json_encode(['success' => false, 'message' => 'Search query or category required']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    $where_conditions = ["b.status = 'available'"];
    $params = [];
    
    if (!empty($query)) {
        $where_conditions[] = "(b.title LIKE :query OR b.author LIKE :query OR b.isbn LIKE :query)";
        $params[':query'] = "%$query%";
    }
    
    if ($category) {
        $where_conditions[] = "b.category_id = :category";
        $params[':category'] = $category;
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    
    $search_query = "SELECT b.id, b.title, b.author, b.isbn, b.publisher, b.publication_year, 
                           b.available_copies, b.total_copies, c.name as category_name
                    FROM books b 
                    LEFT JOIN categories c ON b.category_id = c.id 
                    WHERE $where_clause 
                    ORDER BY b.title ASC 
                    LIMIT :limit";
    
    $search_stmt = $conn->prepare($search_query);
    foreach ($params as $key => $value) {
        $search_stmt->bindValue($key, $value);
    }
    $search_stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $search_stmt->execute();
    
    $books = $search_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'books' => $books,
        'count' => count($books)
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Search error: ' . $e->getMessage()]);
}
?>
