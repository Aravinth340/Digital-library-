<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

header('Content-Type: application/json');

$auth = new Auth();
if (!$auth->isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$action = isset($input['action']) ? $input['action'] : '';
$reservation_id = isset($input['reservation_id']) ? (int)$input['reservation_id'] : 0;

if (!$reservation_id || !in_array($action, ['cancel', 'fulfill'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid action or reservation ID']);
    exit();
}

$database = new Database();
$conn = $database->getConnection();

try {
    // Get reservation details
    $reservation_query = "SELECT r.*, b.title, u.full_name 
                         FROM reservations r 
                         JOIN books b ON r.book_id = b.id 
                         JOIN users u ON r.user_id = u.id 
                         WHERE r.id = :id AND r.status = 'active'";
    $reservation_stmt = $conn->prepare($reservation_query);
    $reservation_stmt->bindParam(':id', $reservation_id);
    $reservation_stmt->execute();
    $reservation = $reservation_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$reservation) {
        echo json_encode(['success' => false, 'message' => 'Reservation not found or already processed']);
        exit();
    }
    
    // Check permissions
    if ($auth->getUserType() === 'student' && $reservation['user_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'You can only manage your own reservations']);
        exit();
    }
    
    if ($action === 'cancel') {
        // Cancel reservation
        $update_query = "UPDATE reservations SET status = 'cancelled' WHERE id = :id";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bindParam(':id', $reservation_id);
        
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Reservation cancelled successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to cancel reservation']);
        }
        
    } elseif ($action === 'fulfill' && $auth->getUserType() === 'librarian') {
        // Fulfill reservation (convert to borrowing)
        $conn->beginTransaction();
        
        try {
            // Check if book is still available
            $book_check = "SELECT available_copies FROM books WHERE id = :book_id AND available_copies > 0";
            $book_stmt = $conn->prepare($book_check);
            $book_stmt->bindParam(':book_id', $reservation['book_id']);
            $book_stmt->execute();
            $book_availability = $book_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$book_availability) {
                echo json_encode(['success' => false, 'message' => 'Book is no longer available']);
                exit();
            }
            
            // Get loan period
            $settings_query = "SELECT setting_value FROM settings WHERE setting_key = 'loan_period_days'";
            $settings_stmt = $conn->prepare($settings_query);
            $settings_stmt->execute();
            $loan_days = (int)$settings_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
            
            // Create borrowing record
            $borrowed_date = date('Y-m-d');
            $due_date = date('Y-m-d', strtotime("+$loan_days days"));
            
            $borrowing_query = "INSERT INTO borrowings (user_id, book_id, borrowed_date, due_date, status, issued_by) 
                              VALUES (:user_id, :book_id, :borrowed_date, :due_date, 'borrowed', :issued_by)";
            $borrowing_stmt = $conn->prepare($borrowing_query);
            $borrowing_stmt->bindParam(':user_id', $reservation['user_id']);
            $borrowing_stmt->bindParam(':book_id', $reservation['book_id']);
            $borrowing_stmt->bindParam(':borrowed_date', $borrowed_date);
            $borrowing_stmt->bindParam(':due_date', $due_date);
            $borrowing_stmt->bindParam(':issued_by', $_SESSION['user_id']);
            $borrowing_stmt->execute();
            
            // Update book availability
            $update_book = "UPDATE books SET available_copies = available_copies - 1 WHERE id = :book_id";
            $update_book_stmt = $conn->prepare($update_book);
            $update_book_stmt->bindParam(':book_id', $reservation['book_id']);
            $update_book_stmt->execute();
            
            // Update reservation status
            $update_reservation = "UPDATE reservations SET status = 'fulfilled' WHERE id = :id";
            $update_reservation_stmt = $conn->prepare($update_reservation);
            $update_reservation_stmt->bindParam(':id', $reservation_id);
            $update_reservation_stmt->execute();
            
            $conn->commit();
            
            echo json_encode([
                'success' => true, 
                'message' => 'Reservation fulfilled successfully',
                'due_date' => date('M j, Y', strtotime($due_date))
            ]);
            
        } catch (Exception $e) {
            $conn->rollBack();
            echo json_encode(['success' => false, 'message' => 'Failed to fulfill reservation: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action for user type']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
