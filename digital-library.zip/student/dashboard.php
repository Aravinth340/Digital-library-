<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('student');

$database = new Database();
$conn = $database->getConnection();

// Get student's current borrowings
$borrowings_query = "SELECT b.*, bk.title, bk.author, bk.isbn 
                    FROM borrowings b 
                    JOIN books bk ON b.book_id = bk.id 
                    WHERE b.user_id = :user_id AND b.status = 'borrowed' 
                    ORDER BY b.due_date ASC";
$borrowings_stmt = $conn->prepare($borrowings_query);
$borrowings_stmt->bindParam(':user_id', $_SESSION['user_id']);
$borrowings_stmt->execute();
$current_borrowings = $borrowings_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get student's reservations
$reservations_query = "SELECT r.*, bk.title, bk.author 
                      FROM reservations r 
                      JOIN books bk ON r.book_id = bk.id 
                      WHERE r.user_id = :user_id AND r.status = 'active' 
                      ORDER BY r.reservation_date DESC";
$reservations_stmt = $conn->prepare($reservations_query);
$reservations_stmt->bindParam(':user_id', $_SESSION['user_id']);
$reservations_stmt->execute();
$reservations = $reservations_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get overdue books count
$overdue_query = "SELECT COUNT(*) as overdue_count 
                 FROM borrowings 
                 WHERE user_id = :user_id AND status = 'borrowed' AND due_date < CURDATE()";
$overdue_stmt = $conn->prepare($overdue_query);
$overdue_stmt->bindParam(':user_id', $_SESSION['user_id']);
$overdue_stmt->execute();
$overdue_count = $overdue_stmt->fetch(PDO::FETCH_ASSOC)['overdue_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Student Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="browse-books.php">Browse Books</a></li>
                <li><a href="my-books.php">My Books</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="dashboard-header">
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
                <p>Student ID: <?php echo htmlspecialchars($_SESSION['student_id']); ?></p>
            </header>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">📖</div>
                    <div class="stat-info">
                        <h3><?php echo count($current_borrowings); ?></h3>
                        <p>Books Borrowed</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⏰</div>
                    <div class="stat-info">
                        <h3><?php echo $overdue_count; ?></h3>
                        <p>Overdue Books</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🔖</div>
                    <div class="stat-info">
                        <h3><?php echo count($reservations); ?></h3>
                        <p>Active Reservations</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-sections">
                <section class="current-books">
                    <h2>Currently Borrowed Books</h2>
                    <?php if (empty($current_borrowings)): ?>
                        <div class="empty-state">
                            <p>You haven't borrowed any books yet.</p>
                            <a href="browse-books.php" class="btn btn-primary">Browse Books</a>
                        </div>
                    <?php else: ?>
                        <div class="books-grid">
                            <?php foreach ($current_borrowings as $borrowing): ?>
                                <div class="book-card">
                                    <div class="book-info">
                                        <h3><?php echo htmlspecialchars($borrowing['title']); ?></h3>
                                        <p class="author">by <?php echo htmlspecialchars($borrowing['author']); ?></p>
                                        <p class="isbn">ISBN: <?php echo htmlspecialchars($borrowing['isbn']); ?></p>
                                    </div>
                                    <div class="book-dates">
                                        <p class="borrowed-date">Borrowed: <?php echo date('M j, Y', strtotime($borrowing['borrowed_date'])); ?></p>
                                        <p class="due-date <?php echo (strtotime($borrowing['due_date']) < time()) ? 'overdue' : ''; ?>">
                                            Due: <?php echo date('M j, Y', strtotime($borrowing['due_date'])); ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
                
                <section class="quick-actions">
                    <h2>Quick Actions</h2>
                    <div class="actions-grid">
                        <a href="browse-books.php" class="action-card">
                            <div class="action-icon">🔍</div>
                            <h3>Browse Books</h3>
                            <p>Search and discover new books</p>
                        </a>
                        
                        <a href="my-books.php" class="action-card">
                            <div class="action-icon">📚</div>
                            <h3>My Books</h3>
                            <p>View your borrowed books</p>
                        </a>
                        
                        <a href="reservations.php" class="action-card">
                            <div class="action-icon">🔖</div>
                            <h3>Reservations</h3>
                            <p>Manage your book reservations</p>
                        </a>
                        
                        <a href="history.php" class="action-card">
                            <div class="action-icon">📋</div>
                            <h3>History</h3>
                            <p>View your borrowing history</p>
                        </a>
                    </div>
                </section>
            </div>
        </main>
    </div>
</body>
</html>
