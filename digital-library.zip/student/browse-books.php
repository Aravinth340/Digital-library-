<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('student');

$database = new Database();
$conn = $database->getConnection();

// Get search parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Build query
$where_conditions = ["b.status = 'available'"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(b.title LIKE :search OR b.author LIKE :search OR b.isbn LIKE :search)";
    $params[':search'] = "%$search%";
}

if (!empty($category)) {
    $where_conditions[] = "b.category_id = :category";
    $params[':category'] = $category;
}

$where_clause = implode(' AND ', $where_conditions);

// Get books
$books_query = "SELECT b.*, c.name as category_name 
               FROM books b 
               LEFT JOIN categories c ON b.category_id = c.id 
               WHERE $where_clause 
               ORDER BY b.title ASC 
               LIMIT :limit OFFSET :offset";

$books_stmt = $conn->prepare($books_query);
foreach ($params as $key => $value) {
    $books_stmt->bindValue($key, $value);
}
$books_stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$books_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$books_stmt->execute();
$books = $books_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM books b WHERE $where_clause";
$count_stmt = $conn->prepare($count_query);
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_books = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_books / $per_page);

// Get categories for filter
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_stmt = $conn->prepare($categories_query);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Books - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Student Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse-books.php" class="active">Browse Books</a></li>
                <li><a href="my-books.php">My Books</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <h1>Browse Books</h1>
                <p>Discover and reserve books from our collection</p>
            </header>
            
            <div class="search-section">
                <form class="search-form" method="GET">
                    <div class="search-inputs">
                        <input type="text" name="search" placeholder="Search by title, author, or ISBN..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        
                        <select name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo ($category == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>
            
            <div class="results-info">
                <p>Found <?php echo $total_books; ?> books</p>
            </div>
            
            <div class="books-grid">
                <?php if (empty($books)): ?>
                    <div class="empty-state">
                        <p>No books found matching your criteria.</p>
                        <a href="browse-books.php" class="btn btn-primary">View All Books</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($books as $book): ?>
                        <div class="book-card">
                            <div class="book-cover">
                                <img src="/placeholder.svg?height=200&width=150" 
                                     alt="<?php echo htmlspecialchars($book['title']); ?>" loading="lazy">
                            </div>
                            <div class="book-details">
                                <h3><?php echo htmlspecialchars($book['title']); ?></h3>
                                <p class="author">by <?php echo htmlspecialchars($book['author']); ?></p>
                                <p class="category"><?php echo htmlspecialchars($book['category_name'] ?? 'Uncategorized'); ?></p>
                                <p class="availability">
                                    Available: <?php echo $book['available_copies']; ?>/<?php echo $book['total_copies']; ?>
                                </p>
                                <div class="book-actions">
                                    <a href="book-details.php?id=<?php echo $book['id']; ?>" class="btn btn-secondary btn-sm">View Details</a>
                                    <?php if ($book['available_copies'] > 0): ?>
                                        <button onclick="reserveBook(<?php echo $book['id']; ?>)" class="btn btn-primary btn-sm">Reserve</button>
                                    <?php else: ?>
                                        <button class="btn btn-disabled btn-sm" disabled>Not Available</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                           class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary">Next</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script src="../assets/js/student.js"></script>
</body>
</html>
