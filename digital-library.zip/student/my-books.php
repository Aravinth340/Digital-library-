<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('student');

$database = new Database();
$conn = $database->getConnection();

// Get student's current borrowings
$borrowings_query = "SELECT b.*, bk.title, bk.author, bk.isbn, bk.publisher 
                    FROM borrowings b 
                    JOIN books bk ON b.book_id = bk.id 
                    WHERE b.user_id = :user_id AND b.status = 'borrowed' 
                    ORDER BY b.due_date ASC";
$borrowings_stmt = $conn->prepare($borrowings_query);
$borrowings_stmt->bindParam(':user_id', $_SESSION['user_id']);
$borrowings_stmt->execute();
$current_borrowings = $borrowings_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Books - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Student Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="browse-books.php">Browse Books</a></li>
                <li><a href="my-books.php" class="active">My Books</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <h1>My Books</h1>
                <p>Books you currently have borrowed</p>
            </header>
            
            <?php if (empty($current_borrowings)): ?>
                <div class="empty-state">
                    <div class="empty-icon">📚</div>
                    <h2>No books borrowed</h2>
                    <p>You haven't borrowed any books yet. Browse our collection to find something interesting!</p>
                    <a href="browse-books.php" class="btn btn-primary">Browse Books</a>
                </div>
            <?php else: ?>
                <div class="books-list">
                    <?php foreach ($current_borrowings as $borrowing): ?>
                        <div class="book-item">
                            <div class="book-cover">
                                <img src="/placeholder.svg?height=120&width=90" 
                                     alt="<?php echo htmlspecialchars($borrowing['title']); ?>">
                            </div>
                            <div class="book-info">
                                <h3><?php echo htmlspecialchars($borrowing['title']); ?></h3>
                                <p class="author">by <?php echo htmlspecialchars($borrowing['author']); ?></p>
                                <p class="publisher"><?php echo htmlspecialchars($borrowing['publisher']); ?></p>
                                <p class="isbn">ISBN: <?php echo htmlspecialchars($borrowing['isbn']); ?></p>
                            </div>
                            <div class="borrowing-info">
                                <div class="dates">
                                    <p><strong>Borrowed:</strong> <?php echo date('M j, Y', strtotime($borrowing['borrowed_date'])); ?></p>
                                    <p class="due-date <?php echo (strtotime($borrowing['due_date']) < time()) ? 'overdue' : ''; ?>">
                                        <strong>Due:</strong> <?php echo date('M j, Y', strtotime($borrowing['due_date'])); ?>
                                        <?php if (strtotime($borrowing['due_date']) < time()): ?>
                                            <span class="overdue-label">OVERDUE</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="actions">
                                    <button onclick="renewBook(<?php echo $borrowing['id']; ?>)" class="btn btn-secondary btn-sm">Renew</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script src="../assets/js/student.js"></script>
</body>
</html>
