<?php
// Installation and Setup Script
require_once '../config/config.php';

// Check if already installed
if (file_exists('../config/installed.lock')) {
    die('System is already installed. Delete the installed.lock file to reinstall.');
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = trim($_POST['db_host']);
    $db_name = trim($_POST['db_name']);
    $db_user = trim($_POST['db_user']);
    $db_pass = trim($_POST['db_pass']);
    $admin_username = trim($_POST['admin_username']);
    $admin_email = trim($_POST['admin_email']);
    $admin_password = trim($_POST['admin_password']);
    $admin_name = trim($_POST['admin_name']);
    
    // Validation
    if (empty($db_host)) $errors[] = "Database host is required";
    if (empty($db_name)) $errors[] = "Database name is required";
    if (empty($db_user)) $errors[] = "Database username is required";
    if (empty($admin_username)) $errors[] = "Admin username is required";
    if (empty($admin_email)) $errors[] = "Admin email is required";
    if (empty($admin_password)) $errors[] = "Admin password is required";
    if (empty($admin_name)) $errors[] = "Admin name is required";
    
    if (empty($errors)) {
        try {
            // Test database connection
            $dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Run database setup scripts
            $sql_files = [
                '../scripts/01_create_database.sql',
                '../scripts/02_insert_sample_data.sql',
                '../scripts/03_create_indexes.sql'
            ];
            
            foreach ($sql_files as $file) {
                if (file_exists($file)) {
                    $sql = file_get_contents($file);
                    $pdo->exec($sql);
                }
            }
            
            // Create admin user
            $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
            $admin_query = "INSERT INTO users (username, email, password, full_name, user_type, status) 
                           VALUES (:username, :email, :password, :full_name, 'librarian', 'active')
                           ON DUPLICATE KEY UPDATE 
                           password = :password, full_name = :full_name";
            $admin_stmt = $pdo->prepare($admin_query);
            $admin_stmt->execute([
                ':username' => $admin_username,
                ':email' => $admin_email,
                ':password' => $hashed_password,
                ':full_name' => $admin_name
            ]);
            
            // Update database config
            $config_content = "<?php
// Database Configuration (Auto-generated)
class Database {
    private \$host = '$db_host';
    private \$db_name = '$db_name';
    private \$username = '$db_user';
    private \$password = '$db_pass';
    private \$conn;

    public function getConnection() {
        \$this->conn = null;
        
        try {
            \$this->conn = new PDO(
                \"mysql:host=\" . \$this->host . \";dbname=\" . \$this->db_name,
                \$this->username,
                \$this->password
            );
            \$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException \$exception) {
            echo \"Connection error: \" . \$exception->getMessage();
        }
        
        return \$this->conn;
    }
}
?>";
            
            file_put_contents('../config/database.php', $config_content);
            
            // Create installation lock file
            file_put_contents('../config/installed.lock', date('Y-m-d H:i:s'));
            
            $success = true;
            
        } catch (Exception $e) {
            $errors[] = "Installation failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Library Setup</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
<body>
    <div class="container">
        <div class="form-container" style="max-width: 600px; margin: 50px auto;">
            <h1>Digital Library System Setup</h1>
            
            <?php if ($success): ?>
                <div class="success-message">
                    <h2>Installation Complete!</h2>
                    <p>Your digital library system has been successfully installed.</p>
                    <p><strong>Admin Login:</strong> <?php echo htmlspecialchars($admin_username); ?></p>
                    <a href="../index.html" class="btn btn-primary">Go to Library</a>
                </div>
            <?php else: ?>
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <h2>Database Configuration</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="db_host">Database Host</label>
                            <input type="text" id="db_host" name="db_host" required 
                                   value="<?php echo htmlspecialchars($_POST['db_host'] ?? 'localhost'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="db_name">Database Name</label>
                            <input type="text" id="db_name" name="db_name" required 
                                   value="<?php echo htmlspecialchars($_POST['db_name'] ?? 'digital_library'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="db_user">Database Username</label>
                            <input type="text" id="db_user" name="db_user" required 
                                   value="<?php echo htmlspecialchars($_POST['db_user'] ?? 'root'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="db_pass">Database Password</label>
                            <input type="password" id="db_pass" name="db_pass" 
                                   value="<?php echo htmlspecialchars($_POST['db_pass'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <h2>Administrator Account</h2>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="admin_username">Username</label>
                            <input type="text" id="admin_username" name="admin_username" required 
                                   value="<?php echo htmlspecialchars($_POST['admin_username'] ?? 'admin'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_email">Email</label>
                            <input type="email" id="admin_email" name="admin_email" required 
                                   value="<?php echo htmlspecialchars($_POST['admin_email'] ?? 'admin@college.edu'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_password">Password</label>
                            <input type="password" id="admin_password" name="admin_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_name">Full Name</label>
                            <input type="text" id="admin_name" name="admin_name" required 
                                   value="<?php echo htmlspecialchars($_POST['admin_name'] ?? 'System Administrator'); ?>">
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Install System</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
