<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'borrowed';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query
$where_conditions = [];
$params = [];

if (!empty($status)) {
    $where_conditions[] = "b.status = :status";
    $params[':status'] = $status;
}

if (!empty($search)) {
    $where_conditions[] = "(bk.title LIKE :search OR u.full_name LIKE :search OR u.student_id LIKE :search)";
    $params[':search'] = "%$search%";
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get borrowings
$borrowings_query = "SELECT b.*, bk.title, bk.author, bk.isbn, u.full_name, u.student_id, u.email 
                    FROM borrowings b 
                    JOIN books bk ON b.book_id = bk.id 
                    JOIN users u ON b.user_id = u.id 
                    $where_clause 
                    ORDER BY b.borrowed_date DESC 
                    LIMIT :limit OFFSET :offset";

$borrowings_stmt = $conn->prepare($borrowings_query);
foreach ($params as $key => $value) {
    $borrowings_stmt->bindValue($key, $value);
}
$borrowings_stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$borrowings_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$borrowings_stmt->execute();
$borrowings = $borrowings_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count
$count_query = "SELECT COUNT(*) as total FROM borrowings b 
               JOIN books bk ON b.book_id = bk.id 
               JOIN users u ON b.user_id = u.id 
               $where_clause";
$count_stmt = $conn->prepare($count_query);
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_borrowings = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_borrowings / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Borrowings - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php" class="active">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Manage Borrowings</h1>
                        <p>Track and manage book borrowings and returns</p>
                    </div>
                    <div class="header-actions">
                        <a href="issue-book.php" class="btn btn-primary">Issue Book</a>
                        <a href="return-book.php" class="btn btn-secondary">Return Book</a>
                    </div>
                </div>
            </header>
            
            <div class="filters-section">
                <form class="filters-form" method="GET">
                    <div class="filter-inputs">
                        <input type="text" name="search" placeholder="Search by book title, student name, or ID..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        
                        <select name="status">
                            <option value="borrowed" <?php echo ($status == 'borrowed') ? 'selected' : ''; ?>>Active Borrowings</option>
                            <option value="returned" <?php echo ($status == 'returned') ? 'selected' : ''; ?>>Returned</option>
                            <option value="overdue" <?php echo ($status == 'overdue') ? 'selected' : ''; ?>>Overdue</option>
                            <option value="" <?php echo ($status == '') ? 'selected' : ''; ?>>All Status</option>
                        </select>
                        
                        <button type="submit" class="btn btn-secondary">Filter</button>
                        <a href="borrowings.php" class="btn btn-outline">Clear</a>
                    </div>
                </form>
            </div>
            
            <div class="results-info">
                <p>Found <?php echo $total_borrowings; ?> borrowing records</p>
            </div>
            
            <div class="borrowings-table-container">
                <table class="borrowings-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Book</th>
                            <th>Borrowed Date</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($borrowings)): ?>
                            <tr>
                                <td colspan="6" class="empty-row">
                                    <div class="empty-state">
                                        <p>No borrowing records found.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($borrowings as $borrowing): ?>
                                <tr class="<?php echo (strtotime($borrowing['due_date']) < time() && $borrowing['status'] == 'borrowed') ? 'overdue-row' : ''; ?>">
                                    <td class="student-cell">
                                        <div class="student-info">
                                            <h4><?php echo htmlspecialchars($borrowing['full_name']); ?></h4>
                                            <p><?php echo htmlspecialchars($borrowing['student_id']); ?></p>
                                            <p class="email"><?php echo htmlspecialchars($borrowing['email']); ?></p>
                                        </div>
                                    </td>
                                    <td class="book-cell">
                                        <div class="book-info">
                                            <h4><?php echo htmlspecialchars($borrowing['title']); ?></h4>
                                            <p>by <?php echo htmlspecialchars($borrowing['author']); ?></p>
                                            <p class="isbn">ISBN: <?php echo htmlspecialchars($borrowing['isbn']); ?></p>
                                        </div>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($borrowing['borrowed_date'])); ?></td>
                                    <td class="<?php echo (strtotime($borrowing['due_date']) < time() && $borrowing['status'] == 'borrowed') ? 'overdue' : ''; ?>">
                                        <?php echo date('M j, Y', strtotime($borrowing['due_date'])); ?>
                                        <?php if (strtotime($borrowing['due_date']) < time() && $borrowing['status'] == 'borrowed'): ?>
                                            <span class="overdue-label">OVERDUE</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $borrowing['status']; ?>">
                                            <?php echo ucfirst($borrowing['status']); ?>
                                        </span>
                                    </td>
                                    <td class="actions-cell">
                                        <div class="action-buttons">
                                            <?php if ($borrowing['status'] == 'borrowed'): ?>
                                                <button onclick="returnBook(<?php echo $borrowing['id']; ?>)" class="btn btn-sm btn-primary">Return</button>
                                                <button onclick="renewBook(<?php echo $borrowing['id']; ?>)" class="btn btn-sm btn-secondary">Renew</button>
                                            <?php endif; ?>
                                            <button onclick="viewDetails(<?php echo $borrowing['id']; ?>)" class="btn btn-sm btn-outline">Details</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                           class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary">Next</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script src="../assets/js/librarian.js"></script>
</body>
</html>
