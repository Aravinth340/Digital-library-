<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get book ID
$book_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$book_id) {
    header('Location: manage-books.php');
    exit();
}

// Get book details with category
$book_query = "SELECT b.*, c.name as category_name 
               FROM books b 
               LEFT JOIN categories c ON b.category_id = c.id 
               WHERE b.id = :id";
$book_stmt = $conn->prepare($book_query);
$book_stmt->bindParam(':id', $book_id);
$book_stmt->execute();
$book = $book_stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
    header('Location: manage-books.php?error=book_not_found');
    exit();
}

// Get borrowing history
$history_query = "SELECT b.*, u.full_name, u.student_id 
                 FROM borrowings b 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.book_id = :book_id 
                 ORDER BY b.borrowed_date DESC 
                 LIMIT 10";
$history_stmt = $conn->prepare($history_query);
$history_stmt->bindParam(':book_id', $book_id);
$history_stmt->execute();
$borrowing_history = $history_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get current borrowings
$current_query = "SELECT b.*, u.full_name, u.student_id, u.email 
                 FROM borrowings b 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.book_id = :book_id AND b.status = 'borrowed'";
$current_stmt = $conn->prepare($current_query);
$current_stmt->bindParam(':book_id', $book_id);
$current_stmt->execute();
$current_borrowings = $current_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Details - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php" class="active">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Book Details</h1>
                        <p>Complete information about this book</p>
                    </div>
                    <div class="header-actions">
                        <a href="edit-book.php?id=<?php echo $book['id']; ?>" class="btn btn-primary">Edit Book</a>
                        <a href="manage-books.php" class="btn btn-secondary">Back to Books</a>
                    </div>
                </div>
            </header>
            
            <div class="book-details-container">
                <div class="book-info-card">
                    <div class="book-cover-section">
                        <img src="/placeholder.svg?height=300&width=200" 
                             alt="<?php echo htmlspecialchars($book['title']); ?>" class="book-cover-large">
                    </div>
                    
                    <div class="book-info-section">
                        <h2><?php echo htmlspecialchars($book['title']); ?></h2>
                        <p class="author">by <?php echo htmlspecialchars($book['author']); ?></p>
                        
                        <div class="book-meta">
                            <div class="meta-item">
                                <strong>ISBN:</strong> <?php echo htmlspecialchars($book['isbn']); ?>
                            </div>
                            <?php if ($book['publisher']): ?>
                                <div class="meta-item">
                                    <strong>Publisher:</strong> <?php echo htmlspecialchars($book['publisher']); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($book['publication_year']): ?>
                                <div class="meta-item">
                                    <strong>Year:</strong> <?php echo htmlspecialchars($book['publication_year']); ?>
                                </div>
                            <?php endif; ?>
                            <div class="meta-item">
                                <strong>Category:</strong> <?php echo htmlspecialchars($book['category_name'] ?? 'Uncategorized'); ?>
                            </div>
                            <?php if ($book['shelf_location']): ?>
                                <div class="meta-item">
                                    <strong>Location:</strong> <?php echo htmlspecialchars($book['shelf_location']); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="availability-info">
                            <div class="availability-item">
                                <span class="label">Total Copies:</span>
                                <span class="value"><?php echo $book['total_copies']; ?></span>
                            </div>
                            <div class="availability-item">
                                <span class="label">Available:</span>
                                <span class="value available"><?php echo $book['available_copies']; ?></span>
                            </div>
                            <div class="availability-item">
                                <span class="label">Status:</span>
                                <span class="status-badge status-<?php echo $book['status']; ?>">
                                    <?php echo ucfirst($book['status']); ?>
                                </span>
                            </div>
                        </div>
                        
                        <?php if ($book['description']): ?>
                            <div class="description">
                                <h3>Description</h3>
                                <p><?php echo nl2br(htmlspecialchars($book['description'])); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <?php if (!empty($current_borrowings)): ?>
                    <div class="current-borrowings-section">
                        <h3>Currently Borrowed By</h3>
                        <div class="borrowings-list">
                            <?php foreach ($current_borrowings as $borrowing): ?>
                                <div class="borrowing-item">
                                    <div class="borrower-info">
                                        <h4><?php echo htmlspecialchars($borrowing['full_name']); ?></h4>
                                        <p><?php echo htmlspecialchars($borrowing['student_id']); ?></p>
                                        <p class="email"><?php echo htmlspecialchars($borrowing['email']); ?></p>
                                    </div>
                                    <div class="borrowing-dates">
                                        <p><strong>Borrowed:</strong> <?php echo date('M j, Y', strtotime($borrowing['borrowed_date'])); ?></p>
                                        <p class="<?php echo (strtotime($borrowing['due_date']) < time()) ? 'overdue' : ''; ?>">
                                            <strong>Due:</strong> <?php echo date('M j, Y', strtotime($borrowing['due_date'])); ?>
                                            <?php if (strtotime($borrowing['due_date']) < time()): ?>
                                                <span class="overdue-label">OVERDUE</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="borrowing-history-section">
                    <h3>Borrowing History</h3>
                    <?php if (empty($borrowing_history)): ?>
                        <p class="no-history">No borrowing history available.</p>
                    <?php else: ?>
                        <div class="history-list">
                            <?php foreach ($borrowing_history as $history): ?>
                                <div class="history-item">
                                    <div class="borrower-info">
                                        <h4><?php echo htmlspecialchars($history['full_name']); ?></h4>
                                        <p><?php echo htmlspecialchars($history['student_id']); ?></p>
                                    </div>
                                    <div class="history-dates">
                                        <p><strong>Borrowed:</strong> <?php echo date('M j, Y', strtotime($history['borrowed_date'])); ?></p>
                                        <p><strong>Due:</strong> <?php echo date('M j, Y', strtotime($history['due_date'])); ?></p>
                                        <?php if ($history['return_date']): ?>
                                            <p><strong>Returned:</strong> <?php echo date('M j, Y', strtotime($history['return_date'])); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="history-status">
                                        <span class="status-badge status-<?php echo $history['status']; ?>">
                                            <?php echo ucfirst($history['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
