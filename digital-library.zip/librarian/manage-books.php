<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get search parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

// Build query
$where_conditions = ["1=1"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(b.title LIKE :search OR b.author LIKE :search OR b.isbn LIKE :search)";
    $params[':search'] = "%$search%";
}

if (!empty($category)) {
    $where_conditions[] = "b.category_id = :category";
    $params[':category'] = $category;
}

if (!empty($status)) {
    $where_conditions[] = "b.status = :status";
    $params[':status'] = $status;
}

$where_clause = implode(' AND ', $where_conditions);

// Get books
$books_query = "SELECT b.*, c.name as category_name 
               FROM books b 
               LEFT JOIN categories c ON b.category_id = c.id 
               WHERE $where_clause 
               ORDER BY b.title ASC 
               LIMIT :limit OFFSET :offset";

$books_stmt = $conn->prepare($books_query);
foreach ($params as $key => $value) {
    $books_stmt->bindValue($key, $value);
}
$books_stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$books_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$books_stmt->execute();
$books = $books_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total count
$count_query = "SELECT COUNT(*) as total FROM books b WHERE $where_clause";
$count_stmt = $conn->prepare($count_query);
foreach ($params as $key => $value) {
    $count_stmt->bindValue($key, $value);
}
$count_stmt->execute();
$total_books = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_books / $per_page);

// Get categories
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_stmt = $conn->prepare($categories_query);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Books - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php" class="active">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Manage Books</h1>
                        <p>Add, edit, and manage your library collection</p>
                    </div>
                    <a href="add-book.php" class="btn btn-primary">Add New Book</a>
                </div>
            </header>
            
            <div class="filters-section">
                <form class="filters-form" method="GET">
                    <div class="filter-inputs">
                        <input type="text" name="search" placeholder="Search by title, author, or ISBN..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        
                        <select name="category">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo ($category == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select name="status">
                            <option value="">All Status</option>
                            <option value="available" <?php echo ($status == 'available') ? 'selected' : ''; ?>>Available</option>
                            <option value="maintenance" <?php echo ($status == 'maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                            <option value="lost" <?php echo ($status == 'lost') ? 'selected' : ''; ?>>Lost</option>
                        </select>
                        
                        <button type="submit" class="btn btn-secondary">Filter</button>
                        <a href="manage-books.php" class="btn btn-outline">Clear</a>
                    </div>
                </form>
            </div>
            
            <div class="results-info">
                <p>Found <?php echo $total_books; ?> books</p>
            </div>
            
            <div class="books-table-container">
                <table class="books-table">
                    <thead>
                        <tr>
                            <th>Book Details</th>
                            <th>Category</th>
                            <th>Copies</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($books)): ?>
                            <tr>
                                <td colspan="5" class="empty-row">
                                    <div class="empty-state">
                                        <p>No books found matching your criteria.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($books as $book): ?>
                                <tr>
                                    <td class="book-details-cell">
                                        <div class="book-info">
                                            <h4><?php echo htmlspecialchars($book['title']); ?></h4>
                                            <p class="author">by <?php echo htmlspecialchars($book['author']); ?></p>
                                            <p class="isbn">ISBN: <?php echo htmlspecialchars($book['isbn']); ?></p>
                                            <?php if ($book['publisher']): ?>
                                                <p class="publisher"><?php echo htmlspecialchars($book['publisher']); ?> (<?php echo $book['publication_year']; ?>)</p>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="category-badge">
                                            <?php echo htmlspecialchars($book['category_name'] ?? 'Uncategorized'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="copies-info">
                                            <span class="available"><?php echo $book['available_copies']; ?></span>
                                            <span class="separator">/</span>
                                            <span class="total"><?php echo $book['total_copies']; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo $book['status']; ?>">
                                            <?php echo ucfirst($book['status']); ?>
                                        </span>
                                    </td>
                                    <td class="actions-cell">
                                        <div class="action-buttons">
                                            <a href="edit-book.php?id=<?php echo $book['id']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                                            <button onclick="deleteBook(<?php echo $book['id']; ?>)" class="btn btn-sm btn-danger">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                           class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary">Next</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script src="../assets/js/librarian.js"></script>
</body>
</html>
