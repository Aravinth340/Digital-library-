<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

$errors = [];
$success = false;
$borrowing_info = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search_identifier = trim($_POST['search_identifier']);
    $borrowing_id = isset($_POST['borrowing_id']) ? (int)$_POST['borrowing_id'] : 0;
    $fine_amount = isset($_POST['fine_amount']) ? (float)$_POST['fine_amount'] : 0;
    $notes = trim($_POST['notes']);
    
    if ($borrowing_id) {
        // Process return
        try {
            $conn->beginTransaction();
            
            // Get borrowing details
            $borrowing_query = "SELECT b.*, bk.title, bk.author, u.full_name, u.student_id 
                              FROM borrowings b 
                              JOIN books bk ON b.book_id = bk.id 
                              JOIN users u ON b.user_id = u.id 
                              WHERE b.id = :id AND b.status = 'borrowed'";
            $borrowing_stmt = $conn->prepare($borrowing_query);
            $borrowing_stmt->bindParam(':id', $borrowing_id);
            $borrowing_stmt->execute();
            $borrowing = $borrowing_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$borrowing) {
                $errors[] = "Borrowing record not found or already returned";
            } else {
                // Update borrowing record
                $return_date = date('Y-m-d');
                $status = (strtotime($borrowing['due_date']) < time()) ? 'overdue' : 'returned';
                
                $update_borrowing = "UPDATE borrowings SET 
                                   return_date = :return_date, 
                                   status = 'returned', 
                                   fine_amount = :fine_amount, 
                                   notes = :notes, 
                                   returned_to = :returned_to 
                                   WHERE id = :id";
                $update_stmt = $conn->prepare($update_borrowing);
                $update_stmt->bindParam(':return_date', $return_date);
                $update_stmt->bindParam(':fine_amount', $fine_amount);
                $update_stmt->bindParam(':notes', $notes);
                $update_stmt->bindParam(':returned_to', $_SESSION['user_id']);
                $update_stmt->bindParam(':id', $borrowing_id);
                $update_stmt->execute();
                
                // Update book availability
                $update_book = "UPDATE books SET available_copies = available_copies + 1 WHERE id = :book_id";
                $update_book_stmt = $conn->prepare($update_book);
                $update_book_stmt->bindParam(':book_id', $borrowing['book_id']);
                $update_book_stmt->execute();
                
                // Add fine record if applicable
                if ($fine_amount > 0) {
                    $fine_reason = (strtotime($borrowing['due_date']) < time()) ? 'Overdue return' : 'Damage/Loss fee';
                    $insert_fine = "INSERT INTO fines (user_id, borrowing_id, amount, reason, status) 
                                  VALUES (:user_id, :borrowing_id, :amount, :reason, 'pending')";
                    $fine_stmt = $conn->prepare($insert_fine);
                    $fine_stmt->bindParam(':user_id', $borrowing['user_id']);
                    $fine_stmt->bindParam(':borrowing_id', $borrowing_id);
                    $fine_stmt->bindParam(':amount', $fine_amount);
                    $fine_stmt->bindParam(':reason', $fine_reason);
                    $fine_stmt->execute();
                }
                
                $conn->commit();
                $success = true;
                $_POST = [];
                $borrowing_info = null;
            }
            
        } catch (Exception $e) {
            $conn->rollBack();
            $errors[] = "Failed to process return: " . $e->getMessage();
        }
        
    } elseif (!empty($search_identifier)) {
        // Search for borrowing
        try {
            $search_query = "SELECT b.*, bk.title, bk.author, bk.isbn, u.full_name, u.student_id, u.email 
                           FROM borrowings b 
                           JOIN books bk ON b.book_id = bk.id 
                           JOIN users u ON b.user_id = u.id 
                           WHERE b.status = 'borrowed' AND 
                           (bk.isbn = :identifier OR bk.title LIKE :title_search OR 
                            u.student_id = :identifier OR u.username = :identifier)";
            $search_stmt = $conn->prepare($search_query);
            $search_stmt->bindParam(':identifier', $search_identifier);
            $title_search = "%$search_identifier%";
            $search_stmt->bindParam(':title_search', $title_search);
            $search_stmt->execute();
            $borrowing_info = $search_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$borrowing_info) {
                $errors[] = "No active borrowing found for the given identifier";
            }
            
        } catch (Exception $e) {
            $errors[] = "Search error: " . $e->getMessage();
        }
    } else {
        $errors[] = "Please enter a search identifier";
    }
}

// Calculate fine if borrowing is overdue
$calculated_fine = 0;
if ($borrowing_info && strtotime($borrowing_info['due_date']) < time()) {
    $days_overdue = floor((time() - strtotime($borrowing_info['due_date'])) / (60 * 60 * 24));
    
    // Get fine per day setting
    $fine_query = "SELECT setting_value FROM settings WHERE setting_key = 'fine_per_day'";
    $fine_stmt = $conn->prepare($fine_query);
    $fine_stmt->execute();
    $fine_per_day = (float)$fine_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
    
    $calculated_fine = $days_overdue * $fine_per_day;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Book - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php" class="active">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Return Book</h1>
                        <p>Process book returns and calculate fines</p>
                    </div>
                    <a href="borrowings.php" class="btn btn-secondary">Back to Borrowings</a>
                </div>
            </header>
            
            <div class="form-container">
                <?php if ($success): ?>
                    <div class="success-message">
                        <p>Book returned successfully!</p>
                        <a href="return-book.php" class="btn btn-primary">Process Another Return</a>
                        <a href="borrowings.php" class="btn btn-secondary">View Borrowings</a>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if (!$borrowing_info): ?>
                    <form class="search-form" method="POST" action="">
                        <div class="form-group">
                            <label for="search_identifier">Search for Book Return</label>
                            <input type="text" id="search_identifier" name="search_identifier" required 
                                   placeholder="Enter ISBN, book title, student ID, or username"
                                   value="<?php echo htmlspecialchars($_POST['search_identifier'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="borrowing-details">
                        <h3>Borrowing Details</h3>
                        <div class="details-grid">
                            <div class="detail-card">
                                <h4>Book Information</h4>
                                <p><strong>Title:</strong> <?php echo htmlspecialchars($borrowing_info['title']); ?></p>
                                <p><strong>Author:</strong> <?php echo htmlspecialchars($borrowing_info['author']); ?></p>
                                <p><strong>ISBN:</strong> <?php echo htmlspecialchars($borrowing_info['isbn']); ?></p>
                            </div>
                            
                            <div class="detail-card">
                                <h4>Student Information</h4>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($borrowing_info['full_name']); ?></p>
                                <p><strong>Student ID:</strong> <?php echo htmlspecialchars($borrowing_info['student_id']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($borrowing_info['email']); ?></p>
                            </div>
                            
                            <div class="detail-card">
                                <h4>Borrowing Information</h4>
                                <p><strong>Borrowed:</strong> <?php echo date('M j, Y', strtotime($borrowing_info['borrowed_date'])); ?></p>
                                <p><strong>Due:</strong> <?php echo date('M j, Y', strtotime($borrowing_info['due_date'])); ?></p>
                                <?php if (strtotime($borrowing_info['due_date']) < time()): ?>
                                    <p class="overdue"><strong>Status:</strong> OVERDUE</p>
                                    <p class="overdue"><strong>Days Overdue:</strong> <?php echo floor((time() - strtotime($borrowing_info['due_date'])) / (60 * 60 * 24)); ?></p>
                                <?php else: ?>
                                    <p class="on-time"><strong>Status:</strong> On Time</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <form class="return-form" method="POST" action="">
                        <input type="hidden" name="borrowing_id" value="<?php echo $borrowing_info['id']; ?>">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="fine_amount">Fine Amount ($)</label>
                                <input type="number" id="fine_amount" name="fine_amount" 
                                       min="0" step="0.01" value="<?php echo $calculated_fine; ?>">
                                <?php if ($calculated_fine > 0): ?>
                                    <small class="fine-note">Calculated overdue fine: $<?php echo number_format($calculated_fine, 2); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group full-width">
                            <label for="notes">Notes (Optional)</label>
                            <textarea id="notes" name="notes" rows="3" 
                                      placeholder="Any notes about the book condition or return..."></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Process Return</button>
                            <a href="return-book.php" class="btn btn-secondary">Search Again</a>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
