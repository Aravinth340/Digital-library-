<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get book ID
$book_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$book_id) {
    header('Location: manage-books.php');
    exit();
}

// Get book details
$book_query = "SELECT * FROM books WHERE id = :id";
$book_stmt = $conn->prepare($book_query);
$book_stmt->bindParam(':id', $book_id);
$book_stmt->execute();
$book = $book_stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
    header('Location: manage-books.php?error=book_not_found');
    exit();
}

// Get categories for dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_stmt = $conn->prepare($categories_query);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $isbn = trim($_POST['isbn']);
    $publisher = trim($_POST['publisher']);
    $publication_year = trim($_POST['publication_year']);
    $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $total_copies = (int)$_POST['total_copies'];
    $available_copies = (int)$_POST['available_copies'];
    $description = trim($_POST['description']);
    $shelf_location = trim($_POST['shelf_location']);
    $status = $_POST['status'];
    
    // Validation
    if (empty($title)) $errors[] = "Title is required";
    if (empty($author)) $errors[] = "Author is required";
    if (empty($isbn)) $errors[] = "ISBN is required";
    if ($total_copies < 1) $errors[] = "Total copies must be at least 1";
    if ($available_copies < 0) $errors[] = "Available copies cannot be negative";
    if ($available_copies > $total_copies) $errors[] = "Available copies cannot exceed total copies";
    
    // Check if ISBN already exists (excluding current book)
    if (!empty($isbn)) {
        $isbn_check_query = "SELECT id FROM books WHERE isbn = :isbn AND id != :id";
        $isbn_check_stmt = $conn->prepare($isbn_check_query);
        $isbn_check_stmt->bindParam(':isbn', $isbn);
        $isbn_check_stmt->bindParam(':id', $book_id);
        $isbn_check_stmt->execute();
        if ($isbn_check_stmt->rowCount() > 0) {
            $errors[] = "A book with this ISBN already exists";
        }
    }
    
    // If no errors, update the book
    if (empty($errors)) {
        try {
            $update_query = "UPDATE books SET 
                           title = :title, 
                           author = :author, 
                           isbn = :isbn, 
                           publisher = :publisher, 
                           publication_year = :publication_year, 
                           category_id = :category_id, 
                           total_copies = :total_copies, 
                           available_copies = :available_copies, 
                           description = :description, 
                           shelf_location = :shelf_location, 
                           status = :status,
                           updated_at = CURRENT_TIMESTAMP
                           WHERE id = :id";
            
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bindParam(':title', $title);
            $update_stmt->bindParam(':author', $author);
            $update_stmt->bindParam(':isbn', $isbn);
            $update_stmt->bindParam(':publisher', $publisher);
            $update_stmt->bindParam(':publication_year', $publication_year);
            $update_stmt->bindParam(':category_id', $category_id);
            $update_stmt->bindParam(':total_copies', $total_copies);
            $update_stmt->bindParam(':available_copies', $available_copies);
            $update_stmt->bindParam(':description', $description);
            $update_stmt->bindParam(':shelf_location', $shelf_location);
            $update_stmt->bindParam(':status', $status);
            $update_stmt->bindParam(':id', $book_id);
            
            if ($update_stmt->execute()) {
                $success = true;
                // Refresh book data
                $book_stmt->execute();
                $book = $book_stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $errors[] = "Failed to update book in database";
            }
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php" class="active">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Edit Book</h1>
                        <p>Update book information and availability</p>
                    </div>
                    <a href="manage-books.php" class="btn btn-secondary">Back to Books</a>
                </div>
            </header>
            
            <div class="form-container">
                <?php if ($success): ?>
                    <div class="success-message">
                        <p>Book updated successfully!</p>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form class="book-form" method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($book['title']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="author">Author *</label>
                            <input type="text" id="author" name="author" required 
                                   value="<?php echo htmlspecialchars($book['author']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="isbn">ISBN *</label>
                            <input type="text" id="isbn" name="isbn" required 
                                   value="<?php echo htmlspecialchars($book['isbn']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="publisher">Publisher</label>
                            <input type="text" id="publisher" name="publisher" 
                                   value="<?php echo htmlspecialchars($book['publisher']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="publication_year">Publication Year</label>
                            <input type="number" id="publication_year" name="publication_year" 
                                   min="1000" max="<?php echo date('Y'); ?>"
                                   value="<?php echo htmlspecialchars($book['publication_year']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="category_id">Category</label>
                            <select id="category_id" name="category_id">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" 
                                            <?php echo ($book['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="total_copies">Total Copies *</label>
                            <input type="number" id="total_copies" name="total_copies" required 
                                   min="1" value="<?php echo htmlspecialchars($book['total_copies']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="available_copies">Available Copies *</label>
                            <input type="number" id="available_copies" name="available_copies" required 
                                   min="0" value="<?php echo htmlspecialchars($book['available_copies']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="shelf_location">Shelf Location</label>
                            <input type="text" id="shelf_location" name="shelf_location" 
                                   placeholder="e.g., A1-001"
                                   value="<?php echo htmlspecialchars($book['shelf_location']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" required>
                                <option value="available" <?php echo ($book['status'] == 'available') ? 'selected' : ''; ?>>Available</option>
                                <option value="maintenance" <?php echo ($book['status'] == 'maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                                <option value="lost" <?php echo ($book['status'] == 'lost') ? 'selected' : ''; ?>>Lost</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" 
                                  placeholder="Brief description of the book..."><?php echo htmlspecialchars($book['description']); ?></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Book</button>
                        <a href="manage-books.php" class="btn btn-secondary">Cancel</a>
                        <button type="button" onclick="deleteBook(<?php echo $book['id']; ?>)" class="btn btn-danger">Delete Book</button>
                    </div>
                </form>
            </div>
        </main>
    </div>
    
    <script src="../assets/js/librarian.js"></script>
</body>
</html>
