<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get system statistics
$stats = [];

// Total books
$books_query = "SELECT COUNT(*) as total_books FROM books";
$books_stmt = $conn->prepare($books_query);
$books_stmt->execute();
$stats['total_books'] = $books_stmt->fetch(PDO::FETCH_ASSOC)['total_books'];

// Total students
$students_query = "SELECT COUNT(*) as total_students FROM users WHERE user_type = 'student'";
$students_stmt = $conn->prepare($students_query);
$students_stmt->execute();
$stats['total_students'] = $students_stmt->fetch(PDO::FETCH_ASSOC)['total_students'];

// Active borrowings
$borrowings_query = "SELECT COUNT(*) as active_borrowings FROM borrowings WHERE status = 'borrowed'";
$borrowings_stmt = $conn->prepare($borrowings_query);
$borrowings_stmt->execute();
$stats['active_borrowings'] = $borrowings_stmt->fetch(PDO::FETCH_ASSOC)['active_borrowings'];

// Overdue books
$overdue_query = "SELECT COUNT(*) as overdue_books FROM borrowings WHERE status = 'borrowed' AND due_date < CURDATE()";
$overdue_stmt = $conn->prepare($overdue_query);
$overdue_stmt->execute();
$stats['overdue_books'] = $overdue_stmt->fetch(PDO::FETCH_ASSOC)['overdue_books'];

// Recent borrowings
$recent_query = "SELECT b.*, bk.title, u.full_name, u.student_id 
                FROM borrowings b 
                JOIN books bk ON b.book_id = bk.id 
                JOIN users u ON b.user_id = u.id 
                WHERE b.status = 'borrowed' 
                ORDER BY b.borrowed_date DESC 
                LIMIT 5";
$recent_stmt = $conn->prepare($recent_query);
$recent_stmt->execute();
$recent_borrowings = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);

// Books running low
$low_stock_query = "SELECT * FROM books WHERE available_copies <= 1 AND available_copies > 0 ORDER BY available_copies ASC LIMIT 5";
$low_stock_stmt = $conn->prepare($low_stock_query);
$low_stock_stmt->execute();
$low_stock_books = $low_stock_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Librarian Dashboard - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="manage-books.php">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="dashboard-header">
                <h1>Librarian Dashboard</h1>
                <p>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>! Here's your library overview.</p>
            </header>
            
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">📚</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total_books']; ?></h3>
                        <p>Total Books</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👨‍🎓</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['total_students']; ?></h3>
                        <p>Registered Students</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">📖</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['active_borrowings']; ?></h3>
                        <p>Active Borrowings</p>
                    </div>
                </div>
                
                <div class="stat-card alert">
                    <div class="stat-icon">⚠️</div>
                    <div class="stat-info">
                        <h3><?php echo $stats['overdue_books']; ?></h3>
                        <p>Overdue Books</p>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <section class="recent-activity">
                    <div class="section-header">
                        <h2>Recent Borrowings</h2>
                        <a href="borrowings.php" class="btn btn-secondary btn-sm">View All</a>
                    </div>
                    
                    <?php if (empty($recent_borrowings)): ?>
                        <div class="empty-state">
                            <p>No recent borrowings</p>
                        </div>
                    <?php else: ?>
                        <div class="activity-list">
                            <?php foreach ($recent_borrowings as $borrowing): ?>
                                <div class="activity-item">
                                    <div class="activity-info">
                                        <h4><?php echo htmlspecialchars($borrowing['title']); ?></h4>
                                        <p>Borrowed by <?php echo htmlspecialchars($borrowing['full_name']); ?> (<?php echo htmlspecialchars($borrowing['student_id']); ?>)</p>
                                        <span class="activity-date"><?php echo date('M j, Y', strtotime($borrowing['borrowed_date'])); ?></span>
                                    </div>
                                    <div class="activity-status">
                                        <span class="status-badge <?php echo (strtotime($borrowing['due_date']) < time()) ? 'overdue' : 'active'; ?>">
                                            <?php echo (strtotime($borrowing['due_date']) < time()) ? 'Overdue' : 'Active'; ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
                
                <section class="low-stock-alert">
                    <div class="section-header">
                        <h2>Low Stock Alert</h2>
                        <a href="manage-books.php" class="btn btn-secondary btn-sm">Manage Books</a>
                    </div>
                    
                    <?php if (empty($low_stock_books)): ?>
                        <div class="empty-state">
                            <p>All books are well stocked</p>
                        </div>
                    <?php else: ?>
                        <div class="alert-list">
                            <?php foreach ($low_stock_books as $book): ?>
                                <div class="alert-item">
                                    <div class="alert-info">
                                        <h4><?php echo htmlspecialchars($book['title']); ?></h4>
                                        <p>by <?php echo htmlspecialchars($book['author']); ?></p>
                                    </div>
                                    <div class="stock-info">
                                        <span class="stock-count"><?php echo $book['available_copies']; ?>/<?php echo $book['total_copies']; ?></span>
                                        <span class="stock-label">Available</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
            
            <div class="quick-actions-section">
                <h2>Quick Actions</h2>
                <div class="actions-grid">
                    <a href="add-book.php" class="action-card">
                        <div class="action-icon">➕</div>
                        <h3>Add New Book</h3>
                        <p>Add a new book to the library collection</p>
                    </a>
                    
                    <a href="issue-book.php" class="action-card">
                        <div class="action-icon">📤</div>
                        <h3>Issue Book</h3>
                        <p>Issue a book to a student</p>
                    </a>
                    
                    <a href="return-book.php" class="action-card">
                        <div class="action-icon">📥</div>
                        <h3>Return Book</h3>
                        <p>Process book returns</p>
                    </a>
                    
                    <a href="add-user.php" class="action-card">
                        <div class="action-icon">👤</div>
                        <h3>Add Student</h3>
                        <p>Register a new student</p>
                    </a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
