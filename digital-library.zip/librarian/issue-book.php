<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

$errors = [];
$success = false;
$book_info = null;
$student_info = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $book_identifier = trim($_POST['book_identifier']);
    $student_identifier = trim($_POST['student_identifier']);
    $loan_days = (int)$_POST['loan_days'];
    
    if (empty($book_identifier)) $errors[] = "Book identifier is required";
    if (empty($student_identifier)) $errors[] = "Student identifier is required";
    if ($loan_days < 1 || $loan_days > 30) $errors[] = "Loan period must be between 1 and 30 days";
    
    if (empty($errors)) {
        try {
            // Find book by ISBN or title
            $book_query = "SELECT * FROM books WHERE (isbn = :identifier OR title LIKE :title_search) AND status = 'available' AND available_copies > 0";
            $book_stmt = $conn->prepare($book_query);
            $book_stmt->bindParam(':identifier', $book_identifier);
            $title_search = "%$book_identifier%";
            $book_stmt->bindParam(':title_search', $title_search);
            $book_stmt->execute();
            $book = $book_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$book) {
                $errors[] = "Book not found or not available";
            } else {
                $book_info = $book;
            }
            
            // Find student by student ID or username
            $student_query = "SELECT * FROM users WHERE (student_id = :identifier OR username = :identifier) AND user_type = 'student' AND status = 'active'";
            $student_stmt = $conn->prepare($student_query);
            $student_stmt->bindParam(':identifier', $student_identifier);
            $student_stmt->execute();
            $student = $student_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$student) {
                $errors[] = "Student not found or inactive";
            } else {
                $student_info = $student;
                
                // Check if student has reached borrowing limit
                $limit_query = "SELECT COUNT(*) as current_books FROM borrowings WHERE user_id = :user_id AND status = 'borrowed'";
                $limit_stmt = $conn->prepare($limit_query);
                $limit_stmt->bindParam(':user_id', $student['id']);
                $limit_stmt->execute();
                $current_books = $limit_stmt->fetch(PDO::FETCH_ASSOC)['current_books'];
                
                // Get max books setting
                $settings_query = "SELECT setting_value FROM settings WHERE setting_key = 'max_books_per_student'";
                $settings_stmt = $conn->prepare($settings_query);
                $settings_stmt->execute();
                $max_books = (int)$settings_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
                
                if ($current_books >= $max_books) {
                    $errors[] = "Student has reached maximum borrowing limit ($max_books books)";
                }
                
                // Check if student already has this book
                $duplicate_query = "SELECT id FROM borrowings WHERE user_id = :user_id AND book_id = :book_id AND status = 'borrowed'";
                $duplicate_stmt = $conn->prepare($duplicate_query);
                $duplicate_stmt->bindParam(':user_id', $student['id']);
                $duplicate_stmt->bindParam(':book_id', $book['id']);
                $duplicate_stmt->execute();
                
                if ($duplicate_stmt->rowCount() > 0) {
                    $errors[] = "Student already has this book borrowed";
                }
            }
            
            // If no errors, process the borrowing
            if (empty($errors) && $book && $student) {
                $conn->beginTransaction();
                
                try {
                    // Insert borrowing record
                    $borrowed_date = date('Y-m-d');
                    $due_date = date('Y-m-d', strtotime("+$loan_days days"));
                    
                    $insert_query = "INSERT INTO borrowings (user_id, book_id, borrowed_date, due_date, status, issued_by) 
                                   VALUES (:user_id, :book_id, :borrowed_date, :due_date, 'borrowed', :issued_by)";
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->bindParam(':user_id', $student['id']);
                    $insert_stmt->bindParam(':book_id', $book['id']);
                    $insert_stmt->bindParam(':borrowed_date', $borrowed_date);
                    $insert_stmt->bindParam(':due_date', $due_date);
                    $insert_stmt->bindParam(':issued_by', $_SESSION['user_id']);
                    $insert_stmt->execute();
                    
                    // Update book availability
                    $update_query = "UPDATE books SET available_copies = available_copies - 1 WHERE id = :book_id";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bindParam(':book_id', $book['id']);
                    $update_stmt->execute();
                    
                    $conn->commit();
                    $success = true;
                    
                    // Clear form
                    $_POST = [];
                    $book_info = null;
                    $student_info = null;
                    
                } catch (Exception $e) {
                    $conn->rollBack();
                    $errors[] = "Failed to issue book: " . $e->getMessage();
                }
            }
            
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}

// Get default loan period
$default_loan_query = "SELECT setting_value FROM settings WHERE setting_key = 'loan_period_days'";
$default_loan_stmt = $conn->prepare($default_loan_query);
$default_loan_stmt->execute();
$default_loan_days = (int)$default_loan_stmt->fetch(PDO::FETCH_ASSOC)['setting_value'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue Book - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php" class="active">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Issue Book</h1>
                        <p>Issue a book to a student</p>
                    </div>
                    <a href="borrowings.php" class="btn btn-secondary">Back to Borrowings</a>
                </div>
            </header>
            
            <div class="form-container">
                <?php if ($success): ?>
                    <div class="success-message">
                        <p>Book issued successfully!</p>
                        <a href="issue-book.php" class="btn btn-primary">Issue Another Book</a>
                        <a href="borrowings.php" class="btn btn-secondary">View Borrowings</a>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form class="issue-form" method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="book_identifier">Book (ISBN or Title) *</label>
                            <input type="text" id="book_identifier" name="book_identifier" required 
                                   placeholder="Enter ISBN or book title"
                                   value="<?php echo htmlspecialchars($_POST['book_identifier'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="student_identifier">Student (ID or Username) *</label>
                            <input type="text" id="student_identifier" name="student_identifier" required 
                                   placeholder="Enter student ID or username"
                                   value="<?php echo htmlspecialchars($_POST['student_identifier'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="loan_days">Loan Period (Days) *</label>
                            <input type="number" id="loan_days" name="loan_days" required 
                                   min="1" max="30" value="<?php echo $_POST['loan_days'] ?? $default_loan_days; ?>">
                        </div>
                    </div>
                    
                    <?php if ($book_info): ?>
                        <div class="preview-section">
                            <h3>Book Information</h3>
                            <div class="info-card">
                                <h4><?php echo htmlspecialchars($book_info['title']); ?></h4>
                                <p>by <?php echo htmlspecialchars($book_info['author']); ?></p>
                                <p>ISBN: <?php echo htmlspecialchars($book_info['isbn']); ?></p>
                                <p>Available: <?php echo $book_info['available_copies']; ?>/<?php echo $book_info['total_copies']; ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($student_info): ?>
                        <div class="preview-section">
                            <h3>Student Information</h3>
                            <div class="info-card">
                                <h4><?php echo htmlspecialchars($student_info['full_name']); ?></h4>
                                <p>Student ID: <?php echo htmlspecialchars($student_info['student_id']); ?></p>
                                <p>Email: <?php echo htmlspecialchars($student_info['email']); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Issue Book</button>
                        <a href="borrowings.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
