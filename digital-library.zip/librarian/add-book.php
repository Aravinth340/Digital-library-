<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

$auth = new Auth();
$auth->requireLogin('librarian');

$database = new Database();
$conn = $database->getConnection();

// Get categories for dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_stmt = $conn->prepare($categories_query);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $isbn = trim($_POST['isbn']);
    $publisher = trim($_POST['publisher']);
    $publication_year = trim($_POST['publication_year']);
    $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
    $total_copies = (int)$_POST['total_copies'];
    $description = trim($_POST['description']);
    $shelf_location = trim($_POST['shelf_location']);
    
    // Validation
    if (empty($title)) $errors[] = "Title is required";
    if (empty($author)) $errors[] = "Author is required";
    if (empty($isbn)) $errors[] = "ISBN is required";
    if ($total_copies < 1) $errors[] = "Total copies must be at least 1";
    
    // Check if ISBN already exists
    if (!empty($isbn)) {
        $isbn_check_query = "SELECT id FROM books WHERE isbn = :isbn";
        $isbn_check_stmt = $conn->prepare($isbn_check_query);
        $isbn_check_stmt->bindParam(':isbn', $isbn);
        $isbn_check_stmt->execute();
        if ($isbn_check_stmt->rowCount() > 0) {
            $errors[] = "A book with this ISBN already exists";
        }
    }
    
    // If no errors, insert the book
    if (empty($errors)) {
        try {
            $insert_query = "INSERT INTO books (title, author, isbn, publisher, publication_year, category_id, total_copies, available_copies, description, shelf_location, status) 
                           VALUES (:title, :author, :isbn, :publisher, :publication_year, :category_id, :total_copies, :available_copies, :description, :shelf_location, 'available')";
            
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->bindParam(':title', $title);
            $insert_stmt->bindParam(':author', $author);
            $insert_stmt->bindParam(':isbn', $isbn);
            $insert_stmt->bindParam(':publisher', $publisher);
            $insert_stmt->bindParam(':publication_year', $publication_year);
            $insert_stmt->bindParam(':category_id', $category_id);
            $insert_stmt->bindParam(':total_copies', $total_copies);
            $insert_stmt->bindParam(':available_copies', $total_copies); // Initially all copies are available
            $insert_stmt->bindParam(':description', $description);
            $insert_stmt->bindParam(':shelf_location', $shelf_location);
            
            if ($insert_stmt->execute()) {
                $success = true;
                // Clear form data
                $_POST = [];
            } else {
                $errors[] = "Failed to add book to database";
            }
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book - Digital Library</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/librarian.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
<body>
    <div class="dashboard-container">
        <nav class="sidebar librarian-sidebar">
            <div class="sidebar-header">
                <h2>📚 Digital Library</h2>
                <p>Librarian Portal</p>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-books.php" class="active">Manage Books</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="borrowings.php">Borrowings</a></li>
                <li><a href="reservations.php">Reservations</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="../auth/logout.php">Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="page-header">
                <div class="header-content">
                    <div>
                        <h1>Add New Book</h1>
                        <p>Add a new book to the library collection</p>
                    </div>
                    <a href="manage-books.php" class="btn btn-secondary">Back to Books</a>
                </div>
            </header>
            
            <div class="form-container">
                <?php if ($success): ?>
                    <div class="success-message">
                        <p>Book added successfully!</p>
                        <a href="add-book.php" class="btn btn-primary">Add Another Book</a>
                        <a href="manage-books.php" class="btn btn-secondary">View All Books</a>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form class="book-form" method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="author">Author *</label>
                            <input type="text" id="author" name="author" required 
                                   value="<?php echo htmlspecialchars($_POST['author'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="isbn">ISBN *</label>
                            <input type="text" id="isbn" name="isbn" required 
                                   value="<?php echo htmlspecialchars($_POST['isbn'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="publisher">Publisher</label>
                            <input type="text" id="publisher" name="publisher" 
                                   value="<?php echo htmlspecialchars($_POST['publisher'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="publication_year">Publication Year</label>
                            <input type="number" id="publication_year" name="publication_year" 
                                   min="1000" max="<?php echo date('Y'); ?>"
                                   value="<?php echo htmlspecialchars($_POST['publication_year'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="category_id">Category</label>
                            <select id="category_id" name="category_id">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" 
                                            <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="total_copies">Total Copies *</label>
                            <input type="number" id="total_copies" name="total_copies" required 
                                   min="1" value="<?php echo htmlspecialchars($_POST['total_copies'] ?? '1'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="shelf_location">Shelf Location</label>
                            <input type="text" id="shelf_location" name="shelf_location" 
                                   placeholder="e.g., A1-001"
                                   value="<?php echo htmlspecialchars($_POST['shelf_location'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" 
                                  placeholder="Brief description of the book..."><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Book</button>
                        <a href="manage-books.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
