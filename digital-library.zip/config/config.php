<?php
// Application Configuration
define('APP_NAME', 'College Digital Library');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost'); // Change this to your domain

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'digital_library');
define('DB_USER', 'root'); // Change this to your database username
define('DB_PASS', '');     // Change this to your database password

// Session Configuration
define('SESSION_LIFETIME', 3600 * 8); // 8 hours
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
session_set_cookie_params(SESSION_LIFETIME);

// Error Reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('America/New_York'); // Change to your timezone

// File Upload Configuration
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

// Email Configuration (for notifications)
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('FROM_EMAIL', 'library@college.edu');
define('FROM_NAME', 'College Library System');

// Security Configuration
define('BCRYPT_COST', 12);
define('SESSION_NAME', 'LIBRARY_SESSION');

// Application Settings
define('DEFAULT_LOAN_PERIOD', 14); // days
define('MAX_BOOKS_PER_STUDENT', 3);
define('FINE_PER_DAY', 1.00); // dollars
define('MAX_RESERVATION_DAYS', 7);

// Logging
define('LOG_PATH', __DIR__ . '/../logs/');
define('LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR

// Create necessary directories
if (!file_exists(UPLOAD_PATH)) {
    mkdir(UPLOAD_PATH, 0755, true);
}

if (!file_exists(LOG_PATH)) {
    mkdir(LOG_PATH, 0755, true);
}
?>
